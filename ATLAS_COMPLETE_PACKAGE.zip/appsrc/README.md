# CMK 3.0

CMK is a private multimodal AI workspace with chat, web research, photos/files, durable memory, projects, voice input/output, and a permission-gated self-improvement workflow.

Security rules:
- Passwords are never stored in plaintext. Use CMK_ADMIN_PASSWORD_HASH.
- Session cookies are HttpOnly, Secure and SameSite=Lax.
- Password recovery sends a time-limited reset link when SMTP is configured; it never emails the existing password.
- CMK cannot silently modify live production. Evolution follows: proposal -> owner approval -> candidate code in sandbox -> tests -> second owner approval -> source-control deployment.
- Production deployment still requires a source-control deployment connector/credential. The running service never directly overwrites its live source.
