from pathlib import Path
from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Request, Response
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.schemas import AskRequest, AskResponse, MemoryCreate, ProjectCreate, EvolutionRequest, EvolutionApprovalRequest, EvolutionDeployApprovalRequest
from app.agents.core import ask_atlas
from app.memory.store import (init_db, save_memory, list_memories, create_project, list_projects,
                              list_evolution_proposals, get_user_account, create_user_account, list_user_accounts)
from app.evolution.engine import evolution_contract, source_manifest, propose_improvement, approve_candidate_writing, build_candidate, run_candidate_tests, approve_deployment
from app.auth import authenticate, hash_password, bootstrap_admin, make_session, session_user, send_reset_email, verify_reset_token, change_password

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
UPLOAD_DIR = BASE_DIR.parent / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

app = FastAPI(title="CMK", version="3.3.0")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

PUBLIC_API = {"/api/auth/login", "/api/auth/register", "/api/auth/forgot", "/api/auth/reset", "/api/auth/me"}

@app.middleware("http")
async def require_login(request: Request, call_next):
    path = request.url.path
    if path.startswith("/api/") and path not in PUBLIC_API:
        user = session_user(request.cookies.get("cmk_session"))
        if not user:
            return JSONResponse({"detail":"Authentication required"}, status_code=401)
        request.state.cmk_user = user
    return await call_next(request)

@app.post("/api/auth/login")
async def auth_login(request: Request):
    data = await request.json()
    username = str(data.get("username", "")).strip()
    password = str(data.get("password", ""))
    account = authenticate(username, password)
    if not account:
        await __import__('asyncio').sleep(0.35)
        raise HTTPException(status_code=401, detail="Incorrect username or password")
    response = JSONResponse({
        "ok": True,
        "username": username,
        "role": account.get("role", "user"),
        "must_change_password": bool(account.get("must_change_password")),
    })
    response.set_cookie("cmk_session", make_session(username), max_age=60*60*24*30, httponly=True, secure=True, samesite="lax", path="/")
    return response

@app.post("/api/auth/register")
async def auth_register(request: Request):
    data = await request.json()
    username = str(data.get("username", "")).strip()
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))
    if len(username) < 3 or len(username) > 40 or not username.replace('_','').replace('-','').isalnum():
        raise HTTPException(status_code=400, detail="Username must be 3–40 letters, numbers, hyphens or underscores")
    if '@' not in email or len(email) > 254:
        raise HTTPException(status_code=400, detail="Enter a valid email address")
    if len(password) < 12:
        raise HTTPException(status_code=400, detail="Use at least 12 characters for your password")
    if get_user_account(username):
        raise HTTPException(status_code=409, detail="That username is already in use")
    create_user_account(username, email, hash_password(password), role="user", must_change_password=False)
    response = JSONResponse({"ok": True, "username": username, "role": "user", "must_change_password": False})
    response.set_cookie("cmk_session", make_session(username), max_age=60*60*24*30, httponly=True, secure=True, samesite="lax", path="/")
    return response

@app.get("/api/auth/me")
def auth_me(request: Request):
    username = session_user(request.cookies.get("cmk_session"))
    account = get_user_account(username) if username else None
    return {
        "authenticated": bool(account),
        "username": account.get("username", "") if account else "",
        "role": account.get("role", "") if account else "",
        "must_change_password": bool(account.get("must_change_password")) if account else False,
    }

@app.post("/api/auth/change-password")
async def auth_change_password(request: Request):
    username = session_user(request.cookies.get("cmk_session"))
    if not username:
        raise HTTPException(status_code=401, detail="Authentication required")
    data = await request.json()
    current_password = str(data.get("current_password", ""))
    new_password = str(data.get("new_password", ""))
    account = authenticate(username, current_password)
    if not account:
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    if len(new_password) < 12:
        raise HTTPException(status_code=400, detail="Use at least 12 characters for your new password")
    if current_password == new_password:
        raise HTTPException(status_code=400, detail="Choose a different password")
    change_password(username, new_password)
    return {"ok": True}

@app.post("/api/auth/logout")
def auth_logout():
    response = JSONResponse({"ok": True})
    response.delete_cookie("cmk_session", path="/")
    return response

@app.post("/api/auth/forgot")
async def auth_forgot(request: Request):
    data = await request.json()
    username = str(data.get("username", "")).strip()
    sent = False
    try:
        sent = send_reset_email(username)
    except Exception:
        sent = False
    return {"ok": True, "sent": sent, "message": "If the account exists and email recovery is configured, a reset link has been sent."}

@app.post("/api/auth/reset")
async def auth_reset(request: Request):
    data = await request.json()
    token = str(data.get("token", ""))
    new_password = str(data.get("new_password", ""))
    username = verify_reset_token(token)
    if not username:
        raise HTTPException(status_code=400, detail="Reset link is invalid or expired")
    if len(new_password) < 12:
        raise HTTPException(status_code=400, detail="Use at least 12 characters")
    change_password(username, new_password)
    return {"ok": True}


@app.on_event("startup")
def startup():
    init_db()
    bootstrap_admin()

@app.get("/", include_in_schema=False)
def home(): return FileResponse(STATIC_DIR / "index.html")

@app.get("/manifest.webmanifest", include_in_schema=False)
def manifest(): return FileResponse(STATIC_DIR / "manifest.webmanifest", media_type="application/manifest+json")

@app.get("/service-worker.js", include_in_schema=False)
def service_worker(): return FileResponse(STATIC_DIR / "service-worker.js", media_type="application/javascript")

@app.get("/health")
def health():
    return {"status":"ok","system":"CMK","version":"3.4.0","ai_configured":bool(settings.openai_api_key),
            "persistent_database":bool(settings.database_url),"web_search":settings.enable_web_search}

@app.post("/api/ask", response_model=AskResponse)
@app.post("/ask", response_model=AskResponse)
async def ask(req: AskRequest, request: Request):
    account = _request_account(request)
    try: return await ask_atlas(req.question, account["username"], req.mode, req.project_id, req.use_web)
    except Exception as exc: raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.post("/api/chat", response_model=AskResponse)
async def chat_with_attachments(
    request: Request,
    question: str = Form(""),
    user_id: str = Form("owner"),
    mode: str = Form("chat"),
    project_id: str | None = Form(None),
    use_web: bool = Form(True),
    files: list[UploadFile] = File(default=[]),
):
    try:
        attachments = []
        total = 0
        for f in files[:10]:
            data = await f.read()
            total += len(data)
            if len(data) > 25 * 1024 * 1024:
                raise HTTPException(status_code=413, detail=f"{f.filename} is larger than 25 MB.")
            if total > 60 * 1024 * 1024:
                raise HTTPException(status_code=413, detail="Attachments exceed the 60 MB message limit.")
            attachments.append({
                "filename": Path(f.filename or "attachment").name,
                "content_type": f.content_type or "application/octet-stream",
                "data": data,
            })
        account = _request_account(request)
        return await ask_atlas(question, account["username"], mode, project_id, use_web, attachments)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

def _request_account(request: Request) -> dict:
    username = getattr(request.state, "cmk_user", None) or session_user(request.cookies.get("cmk_session"))
    account = get_user_account(username) if username else None
    if not account:
        raise HTTPException(status_code=401, detail="Authentication required")
    if bool(account.get("must_change_password")):
        raise HTTPException(status_code=403, detail="Password change required before using CMK")
    return account

def _owner_only(request: Request) -> dict:
    account = _request_account(request)
    if account.get("role") != "owner":
        raise HTTPException(status_code=403, detail="Only the CMK Owner/Administrator can approve system changes")
    return account

@app.get("/api/admin/users")
def admin_users(request: Request):
    _owner_only(request)
    return {"items": list_user_accounts()}

@app.get("/api/memory")
def memories(request: Request, user_id: str = ""): 
    account = _request_account(request)
    return {"items": list_memories(account["username"])}

@app.post("/api/memory")
def add_memory(req: MemoryCreate, request: Request):
    account = _request_account(request)
    save_memory(account["username"], req.topic, req.content, req.kind, req.confidence)
    return {"ok": True}

@app.get("/api/projects")
def projects(request: Request, user_id: str = ""):
    account = _request_account(request)
    return {"items": list_projects(account["username"])}

@app.post("/api/projects")
def add_project(req: ProjectCreate, request: Request):
    account = _request_account(request)
    return create_project(account["username"], req.name, req.description)

@app.post("/api/files")
async def upload_file(request: Request, file: UploadFile = File(...)):
    account = _request_account(request)
    safe = Path(file.filename or "upload.bin").name
    user_dir = UPLOAD_DIR / account["username"]
    user_dir.mkdir(parents=True, exist_ok=True)
    path = user_dir / safe
    path.write_bytes(await file.read())
    return {"ok": True, "name": safe, "size": path.stat().st_size, "note":"Stored in this user's private CMK upload area."}

@app.get("/api/agents")
def agents():
    return {"items":[
        {"name":"CMK Orchestrator","role":"understands goals and synthesises final answers","status":"active"},
        {"name":"Researcher","role":"fresh public research and evidence gathering","status":"active"},
        {"name":"Critic","role":"attacks assumptions and searches for contrary evidence","status":"active"},
        {"name":"Expansion","role":"finds important questions the user did not ask","status":"active"},
        {"name":"Memory Curator","role":"separates durable knowledge from temporary chat","status":"active"},
        {"name":"Evolution Reviewer","role":"proposes tested improvements to CMK itself","status":"active"},
    ]}

@app.get("/api/evolution/policy")
def get_evolution_policy(request: Request):
    _owner_only(request)
    return evolution_contract()

@app.get("/api/evolution/source-manifest")
def get_source_manifest(request: Request):
    _owner_only(request)
    return {"files": source_manifest()}

@app.get("/api/evolution/proposals")
def evolution_proposals(request: Request, user_id: str = ""):
    account = _owner_only(request)
    return {"items": list_evolution_proposals(account["username"])}

@app.post("/api/evolution/propose")
async def evolve(req: EvolutionRequest, request: Request):
    account = _owner_only(request)
    try: return await propose_improvement(account["username"], req.objective)
    except Exception as exc: raise HTTPException(status_code=500, detail=str(exc)) from exc

@app.post("/api/evolution/approve-coding")
def evolution_approve_coding(req: EvolutionApprovalRequest, request: Request):
    account = _owner_only(request)
    try: return approve_candidate_writing(account["username"], req.proposal_id, req.approve)
    except Exception as exc: raise HTTPException(status_code=400, detail=str(exc)) from exc

@app.post("/api/evolution/build-candidate")
async def evolution_build_candidate(req: EvolutionApprovalRequest, request: Request):
    account = _owner_only(request)
    try: return await build_candidate(account["username"], req.proposal_id)
    except Exception as exc: raise HTTPException(status_code=400, detail=str(exc)) from exc

@app.post("/api/evolution/test-candidate")
def evolution_test_candidate(req: EvolutionApprovalRequest, request: Request):
    account = _owner_only(request)
    try: return run_candidate_tests(account["username"], req.proposal_id)
    except Exception as exc: raise HTTPException(status_code=400, detail=str(exc)) from exc

@app.post("/api/evolution/approve-deployment")
def evolution_approve_deployment(req: EvolutionDeployApprovalRequest, request: Request):
    account = _owner_only(request)
    try: return approve_deployment(account["username"], req.proposal_id, req.approve)
    except Exception as exc: raise HTTPException(status_code=400, detail=str(exc)) from exc
