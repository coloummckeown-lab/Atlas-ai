const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let mode='chat', useWeb=true, chatAttachments=[];let tutorSubject='Mathematics', legalSection='Law library', mathsSection='GCSE Mathematics', exeterYear='Year 1';let voiceEnabled=localStorage.getItem('cmk_voice_enabled')!=='0';
let currentUser='', currentRole='', userId='';
let HISTORY_KEY='cmk_local_threads_guest', ACTIVE_KEY='cmk_active_thread_guest';
let threads=[], activeThread='';
function setIdentity(me){
  currentUser=me.username||''; currentRole=me.role||'user'; userId=currentUser;
  HISTORY_KEY='cmk_local_threads_v31_'+currentUser; ACTIVE_KEY='cmk_active_thread_v31_'+currentUser;
  try{threads=JSON.parse(localStorage.getItem(HISTORY_KEY)||'[]')}catch{threads=[]}
  activeThread=localStorage.getItem(ACTIVE_KEY)||'';
  document.querySelectorAll('[data-view="evolution"]').forEach(el=>el.style.display=currentRole==='owner'?'':'none'); const nm=document.querySelector('.account-row strong'); if(nm)nm.textContent=currentUser; const av=document.querySelector('.account-row .avatar'); if(av)av.textContent=(currentUser[0]||'C').toUpperCase();
  renderRecent(); if(activeThread&&thread())loadThread(activeThread); else resetFeed();
}

function showLogin(){
  $('#authGate').hidden=false;$('#appShell').classList.add('auth-hidden');
  $('#loginForm').hidden=false;$('#registerForm').hidden=true;$('#changePasswordForm').hidden=true;
}
function showApp(){
  $('#authGate').hidden=true;$('#appShell').classList.remove('auth-hidden');
}
function requirePasswordChange(me){
  setIdentity(me);$('#authGate').hidden=false;$('#appShell').classList.add('auth-hidden');
  $('#loginForm').hidden=true;$('#registerForm').hidden=true;$('#resetForm').hidden=true;$('#changePasswordForm').hidden=false;
}
async function finishAuth(me){
  setIdentity(me);
  if(me.must_change_password){requirePasswordChange(me);return false}
  showApp();loadHealth();return true;
}
async function checkAuth(){
  try{const me=await api('/api/auth/me');if(me.authenticated)return finishAuth(me)}catch{}
  showLogin();return false;
}
$('#loginForm').onsubmit=async e=>{e.preventDefault();$('#loginError').textContent='';try{const me=await api('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('#loginUsername').value.trim(),password:$('#loginPassword').value})});$('#loginPassword').value='';await finishAuth(me)}catch(err){$('#loginError').textContent=err.message}};
$('#showRegisterBtn').onclick=()=>{$('#loginForm').hidden=true;$('#registerForm').hidden=false;$('#forgotStatus').textContent=''};
$('#backToLoginBtn').onclick=()=>{$('#registerForm').hidden=true;$('#loginForm').hidden=false;$('#registerError').textContent=''};
$('#registerForm').onsubmit=async e=>{e.preventDefault();$('#registerError').textContent='';try{const me=await api('/api/auth/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('#registerUsername').value.trim(),email:$('#registerEmail').value.trim(),password:$('#registerPassword').value})});$('#registerPassword').value='';await finishAuth(me)}catch(err){$('#registerError').textContent=err.message}};
$('#changePasswordForm').onsubmit=async e=>{e.preventDefault();$('#changePasswordError').textContent='';const a=$('#newPassword').value,b=$('#confirmPassword').value;if(a!==b){$('#changePasswordError').textContent='The new passwords do not match';return}try{await api('/api/auth/change-password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({current_password:$('#currentPassword').value,new_password:a})});$('#currentPassword').value='';$('#newPassword').value='';$('#confirmPassword').value='';const me=await api('/api/auth/me');await finishAuth(me)}catch(err){$('#changePasswordError').textContent=err.message}};
$('#forgotBtn').onclick=async()=>{const username=$('#loginUsername').value.trim();$('#forgotStatus').textContent='Requesting reset…';try{const d=await api('/api/auth/forgot',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username})});$('#forgotStatus').textContent=d.sent?'A secure password-reset link has been emailed to the account recovery address.':'Password reset is available, but outbound email still needs to be connected on the server.'}catch(e){$('#forgotStatus').textContent=e.message}};
$('#logoutBtn').onclick=async()=>{try{await api('/api/auth/logout',{method:'POST'})}catch{}currentUser='';currentRole='';userId='';threads=[];activeThread='';showLogin()};
const resetToken=new URLSearchParams(location.search).get('reset_token');if(resetToken){$('#loginForm').hidden=true;$('#resetForm').hidden=false;showLogin();$('#loginForm').hidden=true;$('#resetForm').hidden=false}
$('#resetForm').onsubmit=async e=>{e.preventDefault();$('#resetError').textContent='';try{await api('/api/auth/reset',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:resetToken,new_password:$('#resetPassword').value})});history.replaceState({},'',location.pathname);$('#resetForm').hidden=true;$('#loginForm').hidden=false;$('#forgotStatus').textContent='Password changed. Sign in with your new password.'}catch(err){$('#resetError').textContent=err.message}};

async function api(url,opts={}){const r=await fetch(url,{credentials:'same-origin',...opts});let d;try{d=await r.json()}catch{d={detail:await r.text()}}if(r.status===401&&!url.startsWith('/api/auth/'))showLogin();if(!r.ok)throw new Error(d.detail||'Request failed');return d}
function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function saveThreads(){localStorage.setItem(HISTORY_KEY,JSON.stringify(threads.slice(0,60)));localStorage.setItem(ACTIVE_KEY,activeThread);renderRecent()}
function makeThread(seed='New chat'){const id=Date.now().toString(36)+Math.random().toString(36).slice(2,7);threads.unshift({id,title:seed.slice(0,52)||'New chat',updated:Date.now(),messages:[]});activeThread=id;saveThreads();return threads[0]}
function thread(){return threads.find(t=>t.id===activeThread)}
function ensureThread(seed){return thread()||makeThread(seed)}
function renderRecent(filter=''){const el=$('#recentChats');const items=threads.filter(t=>t.title.toLowerCase().includes(filter.toLowerCase())).slice(0,18);el.innerHTML=items.length?items.map(t=>`<button class="recent-chat" data-thread="${t.id}" title="${esc(t.title)}">${esc(t.title)}</button>`).join(''):'<div style="padding:8px 10px;color:#777;font-size:12px">No chats yet</div>';el.querySelectorAll('button').forEach(b=>b.onclick=()=>loadThread(b.dataset.thread))}
function resetFeed(){const f=$('#chatFeed');f.innerHTML='<div id="welcomeCard" class="welcome-card"><div class="welcome-mark">C</div><h1>What can I help with?</h1></div>'}
function loadThread(id){activeThread=id;saveThreads();switchView('chat');resetFeed();const t=thread();if(!t||!t.messages.length)return;$('#welcomeCard')?.remove();t.messages.forEach(m=>addMsg(m.role,m.text,m.data||{},false));closeSidebar()}
function newChat(){activeThread='';localStorage.removeItem(ACTIVE_KEY);resetFeed();$('#question').value='';chatAttachments=[];renderAttachments();switchView('chat');closeSidebar()}
function setMerlinState(state='idle'){const p=$('#merlinPresence'),t=$('#merlinState');if(!p)return;p.classList.remove('speaking','listening');if(state==='speaking')p.classList.add('speaking');if(state==='listening')p.classList.add('listening');if(t)t.textContent=state==='speaking'?'Speaking':state==='listening'?'Listening':'Merlin'}
function merlinVoice(){const vs=speechSynthesis.getVoices?.()||[];const score=v=>{const n=(v.name||'').toLowerCase(),l=(v.lang||'').toLowerCase();let x=0;if(l.startsWith('en-ie'))x+=100;if(l.startsWith('en-gb'))x+=55;if(/male|daniel|arthur|oliver|liam|connor|conor|ronan|finn/.test(n))x+=30;if(/female|samantha|moira|kate|serena/.test(n))x-=20;return x};return [...vs].sort((a,b)=>score(b)-score(a))[0]||null}
function speakText(text){if(!voiceEnabled||!('speechSynthesis'in window))return;try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);const v=merlinVoice();if(v)u.voice=v;u.lang=(v&&v.lang)||'en-IE';u.rate=.92;u.pitch=.88;u.volume=1;u.onstart=()=>setMerlinState('speaking');u.onend=()=>setMerlinState('idle');u.onerror=()=>setMerlinState('idle');speechSynthesis.speak(u)}catch{setMerlinState('idle')}}
function addMsg(role,text,data={},persist=true){$('#welcomeCard')?.remove();const d=document.createElement('div');d.className=`message ${role}`;let follow='';if(data.recommended_investigations?.length)follow=`<div class="followups">${data.recommended_investigations.slice(0,5).map(x=>`<button class="followup">${esc(x)}</button>`).join('')}</div>`;let src='';if(data.sources?.length)src=`<div class="source-list">${data.sources.slice(0,8).map(s=>`<a target="_blank" rel="noopener" href="${esc(s.url)}">↗ ${esc(s.title||s.url)}</a>`).join('')}</div>`;if(data.open_url)src+=`<a class="web-open" target="_blank" rel="noopener" href="${esc(data.open_url)}">↗ Open on the web</a>`;d.innerHTML=`<div class="bubble">${esc(text)}${data.confidence!=null?`<div class="meta">Confidence ${Math.round(data.confidence*100)}%</div>`:''}${follow}${src}</div>`;$('#chatFeed').appendChild(d);d.querySelectorAll('.followup').forEach(b=>b.onclick=()=>{$('#question').value=b.textContent;autoGrow();sendChat()});if(persist){const t=ensureThread(text);t.messages.push({role,text,data:{confidence:data.confidence,recommended_investigations:data.recommended_investigations||[],sources:data.sources||[]}});if(role==='user'&&t.messages.filter(m=>m.role==='user').length===1)t.title=text.replace(/\n.*/,'').slice(0,52)||'Attachment analysis';t.updated=Date.now();threads.sort((a,b)=>b.updated-a.updated);saveThreads()}if(role==='assistant'&&persist)speakText(text);setTimeout(()=>window.scrollTo({top:document.body.scrollHeight,behavior:'smooth'}),30);return d}
function closeSidebar(){$('#sidebar').classList.remove('open');$('#sidebarShade').classList.remove('show')}
function switchView(name){$$('.view').forEach(v=>v.classList.remove('active'));$(`#view-${name}`)?.classList.add('active');$$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===name));closeSidebar();if(name==='memory')loadMemory();if(name==='projects')loadProjects();if(name==='agents')loadAgents();if(name==='evolution')loadEvolution();if(name==='settings')loadHealth()}
$$('.nav-item').forEach(b=>b.onclick=()=>{if(b.dataset.subject){tutorSubject=b.dataset.subject;renderTutor();switchView('tutor');return}if(b.dataset.maths){mathsSection=b.dataset.maths;renderMaths();switchView('maths');return}if(b.dataset.year){exeterYear=b.dataset.year;renderExeter();switchView('exeter');return}if(b.dataset.legal){legalSection=b.dataset.legal;renderLegal();switchView('legal');return}switchView(b.dataset.view)});
$('#menuBtn').onclick=()=>{$('#sidebar').classList.add('open');$('#sidebarShade').classList.add('show')};$('#sidebarShade').onclick=closeSidebar;$('#newChatBtn').onclick=newChat;

$('#modelBtn').onclick=e=>{e.stopPropagation();$('#modelMenu').hidden=!$('#modelMenu').hidden};$('#modelMenu').onclick=e=>{const b=e.target.closest('[data-mode-choice]');if(!b)return;mode=b.dataset.modeChoice;$('#modelBtn strong').textContent=mode==='research'?'Merlin Research':mode==='tutor'?'Merlin Tutor':'Merlin';$('#modelMenu').hidden=true;$('#activeTool').textContent=mode==='research'?'Deep research':mode==='tutor'?'Tutor mode':'Web '+(useWeb?'on':'off')};
$('#temporaryBtn').onclick=()=>{newChat();alert('Temporary chat is visual-only in this build. Server-side retention controls will be added before this is treated as a private temporary session.')};

function formatBytes(n){if(n<1024)return`${n} B`;if(n<1048576)return`${(n/1024).toFixed(1)} KB`;return`${(n/1048576).toFixed(1)} MB`}
function renderAttachments(){const tray=$('#attachmentTray');tray.innerHTML='';tray.classList.toggle('has-items',chatAttachments.length>0);chatAttachments.forEach((f,i)=>{const item=document.createElement('div');item.className='attachment-chip';if(f.type.startsWith('image/')){const img=document.createElement('img');img.src=URL.createObjectURL(f);item.appendChild(img)}const meta=document.createElement('div');meta.innerHTML=`<strong>${esc(f.name)}</strong><small>${formatBytes(f.size)}</small>`;item.appendChild(meta);const x=document.createElement('button');x.type='button';x.textContent='×';x.onclick=()=>{chatAttachments.splice(i,1);renderAttachments()};item.appendChild(x);tray.appendChild(item)})}
function addAttachments(files){for(const f of [...files]){if(chatAttachments.length>=10)break;if(f.size>25*1024*1024){alert(`${f.name} is larger than 25 MB`);continue}chatAttachments.push(f)}renderAttachments()}
function toggleMenu(which){['attachMenu','toolsMenu','modelMenu'].forEach(id=>{if(id!==which)$('#'+id).hidden=true});const el=$('#'+which);el.hidden=!el.hidden}
$('#attachBtn').onclick=e=>{e.stopPropagation();toggleMenu('attachMenu')};$('#toolsBtn').onclick=e=>{e.stopPropagation();toggleMenu('toolsMenu')};
document.addEventListener('click',e=>{if(!e.target.closest('.pop-menu')&&!e.target.closest('#attachBtn')&&!e.target.closest('#toolsBtn')){$('#attachMenu').hidden=true;$('#toolsMenu').hidden=true}if(!e.target.closest('#modelMenu')&&!e.target.closest('#modelBtn'))$('#modelMenu').hidden=true});
$('#attachMenu').onclick=e=>{const a=e.target.closest('button')?.dataset.action;if(!a)return;$('#attachMenu').hidden=true;if(a==='camera')$('#cameraInput').click();if(a==='photos')$('#photoInput').click();if(a==='files')$('#chatFileInput').click()};
$('#toolsMenu').onclick=e=>{const a=e.target.closest('button')?.dataset.tool;if(!a)return;if(a==='web'){useWeb=!useWeb;$('#webCheck').textContent=useWeb?'✓':'';$('#activeTool').textContent=mode==='research'?'Deep research':mode==='tutor'?'Tutor mode':'Web '+(useWeb?'on':'off');return}if(a==='voice'){voiceEnabled=!voiceEnabled;localStorage.setItem('cmk_voice_enabled',voiceEnabled?'1':'0');$('#voiceCheck').textContent=voiceEnabled?'✓':'';return}$('#toolsMenu').hidden=true;if(a==='research'){mode='research';$('#modelBtn strong').textContent='Merlin Research';$('#activeTool').textContent='Deep research'}if(a==='tutor'){mode='tutor';$('#modelBtn strong').textContent='Merlin Tutor';$('#activeTool').textContent='Tutor mode'}if(a==='camera')$('#cameraInput').click();if(a==='file')$('#chatFileInput').click()};
$('#voiceCheck').textContent=voiceEnabled?'✓':'';
['cameraInput','photoInput','chatFileInput'].forEach(id=>{$('#'+id).onchange=e=>{addAttachments(e.target.files);e.target.value=''}});
function autoGrow(){const q=$('#question');q.style.height='auto';q.style.height=Math.min(q.scrollHeight,170)+'px'}$('#question').addEventListener('input',autoGrow);

async function sendChat(){const q=$('#question').value.trim();if(!q&&!chatAttachments.length)return;const current=[...chatAttachments];$('#question').value='';$('#question').style.height='auto';chatAttachments=[];renderAttachments();const label=q||'Analyse these attachments';addMsg('user',label+(current.length?`\n📎 ${current.map(f=>f.name).join(', ')}`:''));const loading=addMsg('assistant','Thinking…',{},false);try{const fd=new FormData();fd.append('question',q);fd.append('user_id',userId);fd.append('mode',mode);fd.append('use_web',useWeb?'true':'false');current.forEach(f=>fd.append('files',f,f.name));const d=await api('/api/chat',{method:'POST',body:fd});loading.remove();addMsg('assistant',d.answer,d);if(d.open_url&&/(open|bring it up|take me to|show me the website)/i.test(q)){try{window.open(d.open_url,'_blank','noopener')}catch{}}}catch(e){loading.remove();addMsg('assistant',`Merlin error: ${e.message}`)}}
$('#sendBtn').onclick=sendChat;$('#question').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendChat()}});

$('#micBtn').onclick=()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){alert('Voice recognition is not available in this browser. On iPhone, allow microphone access or use the keyboard microphone.');return}voiceEnabled=true;localStorage.setItem('cmk_voice_enabled','1');$('#voiceCheck').textContent='✓';const r=new SR();r.lang='en-IE';r.interimResults=false;r.continuous=false;setMerlinState('listening');$('#micBtn').textContent='●';r.onresult=e=>{const said=e.results[0][0].transcript.trim();$('#question').value=said;autoGrow();setMerlinState('idle');if(said)sendChat()};r.onerror=()=>{setMerlinState('idle');alert('Merlin could not access the microphone. Check microphone permission for CMK.')};r.onend=()=>{$('#micBtn').textContent='⌁';if(!$('#merlinPresence')?.classList.contains('speaking'))setMerlinState('idle')};r.start()};

$('#searchChatsBtn').onclick=()=>{const ov=document.createElement('div');ov.className='search-overlay';ov.innerHTML='<div class="search-box"><input autofocus placeholder="Search chats"><div class="search-results"></div></div>';document.body.appendChild(ov);const input=ov.querySelector('input'),out=ov.querySelector('.search-results');const run=()=>{const list=threads.filter(t=>t.title.toLowerCase().includes(input.value.toLowerCase())).slice(0,30);out.innerHTML=list.map(t=>`<button data-id="${t.id}">${esc(t.title)}</button>`).join('')||'<div style="padding:12px;color:#888">No matches</div>';out.querySelectorAll('button').forEach(b=>b.onclick=()=>{loadThread(b.dataset.id);ov.remove()})};input.oninput=run;ov.onclick=e=>{if(e.target===ov)ov.remove()};run()};
$('#clearHistoryBtn').onclick=()=>{if(confirm('Clear the local Recent chats list on this device? This does not delete CMK server memory.')){threads=[];activeThread='';saveThreads();resetFeed()}};

$('#researchBtn').onclick=async()=>{const q=$('#researchQuestion').value.trim();if(!q)return;$('#researchOutput').innerHTML='<div class="panel">Researching…</div>';try{const d=await api('/api/ask',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:q,user_id:userId,mode:'research',use_web:true})});$('#researchOutput').innerHTML=`<div class="panel"><h2>Investigation</h2><p>${esc(d.answer)}</p><h3>Next investigations</h3><ul>${(d.recommended_investigations||[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div>`}catch(e){$('#researchOutput').innerHTML=`<div class="panel">${esc(e.message)}</div>`}};
async function loadHealth(){try{const h=await api('/health');$('#statusDot').className='dot ok';$('#statusText').textContent=h.ai_configured?'Online':'AI setup needed';$('#systemStatus').innerHTML=Object.entries(h).map(([k,v])=>`<div class="status-row"><strong>${esc(k)}</strong><span>${esc(String(v))}</span></div>`).join('')}catch{$('#statusDot').className='dot bad';$('#statusText').textContent='Offline'}}
async function loadMemory(){const d=await api(`/api/memory?user_id=${encodeURIComponent(userId)}`);$('#memoryList').innerHTML=d.items.length?d.items.map(x=>`<div class="memory-item"><strong>${esc(x.topic)}</strong><p>${esc(x.content)}</p><small>${esc(x.kind)} · ${Math.round((x.confidence||0)*100)}%</small></div>`).join(''):'<div class="panel">No durable memories yet.</div>'}
$('#addMemoryBtn').onclick=async()=>{const topic=prompt('Memory topic');if(!topic)return;const content=prompt('What should CMK remember?');if(!content)return;await api('/api/memory',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:userId,topic,content,kind:'user_fact',confidence:1})});loadMemory()};
async function loadProjects(){const d=await api(`/api/projects?user_id=${encodeURIComponent(userId)}`);$('#projectList').innerHTML=d.items.length?d.items.map(x=>`<div class="card"><h3>${esc(x.name)}</h3><p>${esc(x.description)}</p><small>Project #${x.id}</small></div>`).join(''):'<div class="panel">No projects yet.</div>'}
$('#newProjectBtn').onclick=async()=>{const name=prompt('Project name');if(!name)return;const description=prompt('Short description')||'';await api('/api/projects',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:userId,name,description})});loadProjects()};
async function loadAgents(){const d=await api('/api/agents');$('#agentList').innerHTML=d.items.map(a=>`<div class="card"><h3>${esc(a.name)}</h3><p>${esc(a.role)}</p><small>${esc(a.status)}</small></div>`).join('')}
async function evoAction(url,id,approve=true){try{await api(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:userId,proposal_id:id,approve})});await loadEvolution()}catch(e){alert(e.message)}}
async function loadEvolution(){const [p,l]=await Promise.all([api('/api/evolution/policy'),api(`/api/evolution/proposals?user_id=${userId}`)]);$('#evolutionPolicy').innerHTML='<h3>Evolution policy</h3>'+Object.entries(p).map(([k,v])=>`<div class="status-row"><strong>${esc(k)}</strong><span>${esc(String(v))}</span></div>`).join('');$('#proposalList').innerHTML=l.items.map(x=>{const b=x.body||{};let actions='';if(x.status==='proposed')actions=`<div class="evo-actions"><button class="primary" data-evo="approve" data-id="${x.id}">Allow candidate coding</button><button data-evo="reject" data-id="${x.id}">Reject</button></div>`;if(x.status==='approved_for_sandbox')actions=`<div class="evo-actions"><button class="primary" data-evo="build" data-id="${x.id}">Write candidate in sandbox</button></div>`;if(['candidate_ready','sandbox_failed'].includes(x.status))actions=`<div class="evo-actions"><button class="primary" data-evo="test" data-id="${x.id}">Run sandbox tests</button></div>`;if(x.status==='sandbox_passed')actions=`<div class="evo-actions"><button class="primary" data-evo="deploy" data-id="${x.id}">Approve deployment</button><button data-evo="rejectdeploy" data-id="${x.id}">Do not deploy</button></div>`;const details=`<p><strong>Why:</strong> ${esc(b.rationale||'')}</p><p><strong>Expected benefit:</strong> ${esc(b.expected_benefit||'')}</p><p><strong>Risk:</strong> ${esc(b.risk||'')}</p>`;const test=b.sandbox_test?`<pre class="test-output">${esc((b.sandbox_test.passed?'PASS':'FAIL')+'\n'+(b.sandbox_test.output||''))}</pre>`:'';return `<div class="proposal"><h3>${esc(x.title)}</h3><p>${esc(b.problem||'')}</p>${details}<small>${esc(x.status)}</small>${test}${actions}</div>`}).join('');$('#proposalList').querySelectorAll('[data-evo]').forEach(btn=>btn.onclick=async()=>{const id=Number(btn.dataset.id),a=btn.dataset.evo;if(a==='approve')return evoAction('/api/evolution/approve-coding',id,true);if(a==='reject')return evoAction('/api/evolution/approve-coding',id,false);if(a==='build')return evoAction('/api/evolution/build-candidate',id,true);if(a==='test')return evoAction('/api/evolution/test-candidate',id,true);if(a==='deploy')return evoAction('/api/evolution/approve-deployment',id,true);if(a==='rejectdeploy')return evoAction('/api/evolution/approve-deployment',id,false)})}
$('#proposeBtn').onclick=async()=>{const b=$('#proposeBtn');b.disabled=true;b.textContent='Reviewing CMK…';try{await api('/api/evolution/propose',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:userId,objective:$('#evolutionObjective').value})});await loadEvolution()}catch(e){alert(e.message)}finally{b.disabled=false;b.textContent='Generate improvement proposal'}};
$('#uploadBtn').onclick=async()=>{const f=$('#fileInput').files[0];if(!f)return;const fd=new FormData();fd.append('file',f);try{const d=await api('/api/files',{method:'POST',body:fd});$('#uploadStatus').textContent=`Uploaded ${d.name} (${d.size} bytes)`}catch(e){$('#uploadStatus').textContent=e.message}};
checkAuth();if('serviceWorker'in navigator)navigator.serviceWorker.register('/service-worker.js').catch(()=>{});

if('speechSynthesis'in window){speechSynthesis.getVoices();speechSynthesis.onvoiceschanged=()=>speechSynthesis.getVoices()}


const TUTOR_SUBJECTS=['Mathematics','Finance','Economics','Business','Accounting','Sciences','English & Writing','History & Humanities','Computer Science','Other'];
const LEGAL_LIBRARY={
  'Law library':[
    ['Contract law','Formation, terms, interpretation, breach, remedies, third-party rights and discharge.'],
    ['Tort / delict','Negligence, duty, breach, causation, remoteness, nuisance and economic loss.'],
    ['Company & commercial','Companies, directors, shareholders, agency, sale of goods and commercial obligations.'],
    ['Employment','Contracts, dismissal, discrimination, workplace obligations and remedies.'],
    ['Property & land','Ownership, leases, easements, covenants, development and property transactions.'],
    ['Public & administrative','Public-law powers, judicial review, procurement and regulatory decision-making.'],
    ['Evidence & procedure','Burden/standard of proof, disclosure, limitation, jurisdiction and procedural strategy.'],
    ['International & conflict of laws','Governing law, jurisdiction, recognition/enforcement and cross-border contracts.']
  ],
  'Case studies':[
    ['Case briefing','Facts → issues → rule → reasoning → holding → significance → later treatment.'],
    ['Authority checking','Verify court, jurisdiction, date, neutral citation, status and whether later cases distinguish/overrule it.'],
    ['Construction disputes','Delay/EOT, payment, variation, defects, design responsibility, termination and final account case studies.'],
    ['Contract interpretation','Compare textual, contextual and commercial approaches to disputed wording.'],
    ['Remedies','Damages, liquidated damages, penalties, restitution, specific performance, injunctions and interest.']
  ],
  'Contract law':[
    ['Formation','Offer, acceptance, consideration, intention, capacity and certainty.'],
    ['Terms & incorporation','Express/implied terms, signatures, notices, entire agreement and precedence.'],
    ['Interpretation','Ordinary meaning, context, commercial purpose, ambiguity and document hierarchy.'],
    ['Risk allocation','Indemnities, guarantees, exclusions, caps, insurance, force majeure and hardship.'],
    ['Change & transfer','Variation, waiver, estoppel, assignment, novation and third-party rights.'],
    ['Breach & termination','Conditions/warranties, repudiation, cure, suspension, termination rights and consequences.'],
    ['Remedies','Damages, causation, remoteness, mitigation, penalties, restitution and equitable relief.'],
    ['Disputes','Negotiation, mediation, adjudication, expert determination, arbitration and litigation.']
  ],
  'Construction contracts':[
    ['FIDIC','Red/Yellow/Silver and related forms: notices, Engineer, variations, EOT, claims, payment, tests, completion and disputes.'],
    ['NEC','ECC concepts: early warning, compensation events, accepted programme, quotations, time and cost management.'],
    ['JCT','Traditional/design-build forms: architect/CA roles, relevant events/matters, loss and expense, payment and defects.'],
    ['EPC / turnkey','Single-point responsibility, performance guarantees, testing, LDs, interface and fitness-for-purpose risk.'],
    ['Subcontracts','Flow-down obligations, pay mechanisms, notices, programme, access, coordination, variations and back-to-back risks.'],
    ['Delay & EOT','Critical path, causation, concurrency, prevention, mitigation, notices, time bars and substantiation.'],
    ['Change & valuation','Instructions, variations, dayworks, rates, quantum, disruption, acceleration and prolongation.'],
    ['Payment & final account','Applications, certification, retention, set-off, pay-less/payment notices, final account and release.'],
    ['Design & defects','Design standard, approvals, BIM/interface, workmanship, testing, defects, warranties and limitation.'],
    ['Security & risk','Bonds, guarantees, parent guarantees, insurance, indemnities, caps and exclusions.']
  ],
  'Disputes & claims':[
    ['Entitlement matrix','Clause → event → notice → causation → records → quantum → mitigation → concurrency → remedy.'],
    ['Chronology','Build a dated event timeline from correspondence, programmes, notices, instructions and records.'],
    ['Delay analysis','Windows/time-impact/as-planned vs as-built approaches, critical path and contemporaneous evidence.'],
    ['Quantum','Labour, plant, materials, preliminaries, prolongation, disruption, overheads, finance and interest.'],
    ['Counterarguments','Identify weaknesses, condition precedents, time bars, causation gaps, mitigation and contractual exclusions.'],
    ['Dispute route','Adjudication, DRB/DAAB, arbitration, litigation, mediation and settlement strategy.']
  ]
};


const MATHS_TOPICS={
  'GCSE Mathematics':{
    intro:'Covers the common content used across major UK GCSE Mathematics specifications. Choose Foundation or Higher and Merlin will adapt the difficulty.',
    groups:[
      ['Number',['Integers, decimals and fractions','Percentages and percentage change','Ratio and proportion','Standard form','Bounds and error intervals','Surds (Higher)','Indices and fractional indices (Higher)']],
      ['Algebra',['Expressions and manipulation','Linear equations and inequalities','Sequences','Graphs and gradients','Simultaneous equations','Quadratics (Higher)','Functions and iteration (Higher)']],
      ['Geometry & measures',['Angles and polygons','Perimeter, area and volume','Pythagoras','Trigonometry','Similarity and congruence','Circle theorems (Higher)','Vectors (Higher)','Transformations and constructions']],
      ['Probability',['Single and combined events','Tree diagrams','Venn diagrams','Conditional probability (Higher)']],
      ['Statistics',['Averages and spread','Charts and tables','Scatter graphs','Cumulative frequency (Higher)','Histograms (Higher)']]
    ]
  },
  'A Level Mathematics':{
    intro:'Pure mathematics, statistics and mechanics, aligned to the common UK A Level Mathematics core.',
    groups:[
      ['Pure',['Proof','Algebra and functions','Coordinate geometry','Sequences and series','Trigonometry','Exponentials and logarithms','Differentiation','Integration','Numerical methods','Vectors']],
      ['Statistics',['Sampling','Data presentation and interpretation','Probability','Statistical distributions','Hypothesis testing']],
      ['Mechanics',['Quantities and units','Kinematics','Forces and Newton’s laws','Moments']]
    ]
  }
};
const PAPER_SOURCES=[
  ['AQA Mathematics','GCSE 8300 and A Level 7357','https://www.aqa.org.uk/subjects/mathematics'],
  ['AQA past-paper finder','Official question papers and mark schemes','https://www.aqa.org.uk/past-papers-and-mark-schemes-finder'],
  ['Pearson Edexcel past papers','Official Pearson exam-paper search','https://qualifications.pearson.com/en/support/support-topics/exams/past-papers.html'],
  ['OCR GCSE Mathematics J560','Official assessment papers and mark schemes','https://www.ocr.org.uk/qualifications/gcse/mathematics-j560-from-2015/assessment/'],
  ['OCR A Level Mathematics A H240','Official assessment papers and mark schemes','https://www.ocr.org.uk/qualifications/as-and-a-level/mathematics-a-h230-h240-from-2017/assessment/']
];
function miniMathVisual(){return `<div class="study-visuals"><div class="study-visual"><strong>Linear graph</strong><svg viewBox="0 0 240 130" role="img" aria-label="line graph"><line x1="30" y1="110" x2="225" y2="110"/><line x1="30" y1="110" x2="30" y2="10"/><line x1="35" y1="100" x2="210" y2="25" class="accent-line"/><text x="160" y="42">y = mx + c</text></svg></div><div class="study-visual"><strong>Formula table</strong><table><tr><th>Topic</th><th>Key relation</th></tr><tr><td>Pythagoras</td><td>a²+b²=c²</td></tr><tr><td>Gradient</td><td>Δy/Δx</td></tr><tr><td>Compound growth</td><td>P(1+r)ⁿ</td></tr></table></div></div>`}
function renderMaths(){
  if(!$('#mathsTitle'))return;
  $('#mathsTitle').textContent=`Mathematics · ${mathsSection}`;
  if(mathsSection==='Past papers'){
    const yr=new Date().getFullYear();
    $('#mathsIntro').textContent='Official exam-board paper library. CMK links to the publishers rather than copying restricted papers.';
    $('#mathsLibrary').innerHTML=`<div class="panel"><div class="page-head row"><div><h2>Past-paper library</h2><p>Official sources · checked for ${yr}</p></div><button id="paperRefreshBtn" class="primary">Refresh latest papers</button></div><div class="resource-grid">${PAPER_SOURCES.map(([n,d,u])=>`<a class="resource-card" target="_blank" rel="noopener" href="${u}"><strong>${n}</strong><span>${d}</span><small>Open official source ↗</small></a>`).join('')}</div><p class="library-note">Some boards restrict the newest papers to schools/centres for a period. Merlin should never bypass those restrictions.</p></div><div id="paperUpdateOutput"></div>`;
    $('#paperRefreshBtn').onclick=refreshPastPapers;
    const key='cmk_papers_checked_year';if(localStorage.getItem(key)!==String(yr)){localStorage.setItem(key,String(yr));setTimeout(refreshPastPapers,300)}
    return;
  }
  const d=MATHS_TOPICS[mathsSection];$('#mathsIntro').textContent=d.intro;
  $('#mathsLibrary').innerHTML=`<div class="study-tabs"><button data-tier="Foundation">Foundation</button><button data-tier="Higher">Higher</button></div><div class="topic-grid">${d.groups.map(([g,topics])=>`<div class="study-card"><h3>${g}</h3>${topics.map(t=>`<button class="topic-link" data-maths-topic="${esc(t)}">${esc(t)}</button>`).join('')}</div>`).join('')}</div>${miniMathVisual()}`;
  $$('#mathsLibrary [data-maths-topic]').forEach(b=>b.onclick=()=>{$('#mathsQuestion').value=`Teach me ${b.dataset.mathsTopic} for ${mathsSection}, step by step. Start from the basics and then give me an exam-style example.`;$('#mathsQuestion').focus()});
}
async function refreshPastPapers(){const out=$('#paperUpdateOutput');if(!out)return;out.innerHTML='<div class="panel">Merlin is checking official exam-board sources for the latest public papers…</div>';try{const d=await api('/api/ask',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:`Check the official AQA, Pearson Edexcel and OCR websites for the newest publicly available GCSE Mathematics and A Level Mathematics past papers, mark schemes and examiner reports as of ${new Date().getFullYear()}. Do not bypass teacher-only or restricted materials. Summarise what is newly available and provide official source links.`,mode:'research',use_web:true})});out.innerHTML=`<div class="panel"><h3>Latest paper check</h3><p>${esc(d.answer)}</p>${d.sources?.length?`<div class="source-list">${d.sources.map(s=>`<a target="_blank" rel="noopener" href="${esc(s.url)}">↗ ${esc(s.title||s.url)}</a>`).join('')}</div>`:''}</div>`}catch(e){out.innerHTML=`<div class="panel">${esc(e.message)}</div>`}}
async function runMaths(practice=false){const q=$('#mathsQuestion').value.trim();if(!q)return;$('#mathsOutput').innerHTML='<div class="panel">Merlin is preparing the lesson…</div>';const p=`You are tutoring ${mathsSection}. ${practice?'Create one exam-style practice problem based on this topic, wait for my attempt, then mark it and teach the solution.':'Teach this slowly and step by step, define every symbol, show all working, explain why each step is valid, and finish with one check-for-understanding question.'} ${q}`;try{const d=await api('/api/ask',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:p,mode:'tutor',use_web:true})});$('#mathsOutput').innerHTML=`<div class="panel"><h2>Merlin Maths</h2><p>${esc(d.answer)}</p></div>`}catch(e){$('#mathsOutput').innerHTML=`<div class="panel">${esc(e.message)}</div>`}}

const EXETER_YEARS={
  'Year 1':[
    ['BEA1008','Introduction to Financial Accounting',15,'Accounting equation, double entry, journals/ledgers, trial balance, financial statements, adjustments and interpretation.','accounting'],
    ['BEA1009','Introduction to Management Accounting',15,'Cost behaviour, absorption and marginal costing, CVP, budgeting, variance thinking and decision support.','accounting'],
    ['BEA1014','Statistical Methods for Accounting and Finance',15,'Descriptive statistics, probability, distributions, estimation, hypothesis testing, correlation and regression.','stats'],
    ['BEE1029','Economic Principles',30,'Micro and macro foundations: supply/demand, elasticity, market failure, firms, growth, inflation, unemployment, policy and trade.','economics'],
    ['BEF1015','Finance and Investment',15,'Time value of money, bonds, equities, risk/return, portfolio ideas, valuation and capital markets.','finance'],
    ['BEM1028','Introduction to Business and Management',15,'Organisations, strategy, stakeholders, marketing, operations, people, ethics, sustainability and global context.','business'],
    ['BEM1059','Future You',15,'Academic, employability and professional development: reflection, teamwork, communication and career planning.','skills']
  ],
  'Year 2':[
    ['BEA2018','Corporate Finance',15,'Investment appraisal, cost of capital, capital structure, payout, working capital, governance and financing decisions.','finance'],
    ['BEF2013','Investment Practice',15,'Portfolio construction, asset classes, risk measurement, diversification, performance and practical investment analysis.','finance'],
    ['BEF2014','Financial Reporting and Analysis',15,'Financial statements, accounting quality, ratios, cash flow, earnings analysis and company evaluation.','accounting']
  ],
  'Final year':[
    ['BEA3018','Advanced Corporate Finance',15,'Market efficiency, portfolio theory, derivatives, risk management, M&A and advanced valuation.','finance'],
    ['BEA3028','Sustainable and Responsible Finance',15,'ESG, climate risk, stewardship, sustainable investment, green finance and responsible capital allocation.','esg'],
    ['BEF3009',"Financial Institutions' Risk Management",15,'Credit, market, liquidity, operational and systemic risk; regulation, capital and stress testing.','risk'],
    ['BEF3010','Applied Finance Project',30,'Research question, literature, data, methodology, analysis, visualisation, interpretation, academic writing and presentation.','project']
  ]
};
const EXETER_OPTIONALS={
  'Year 2':['BEM2031 Introduction to Business Analytics','BEM2035 Leading in International Contexts','BEM2037 Leadership: Challenges and Practice','BEM2039 Business Analytics in Practice','BEM2047 Organisational Behaviour','BEM2058 Making Innovation and Entrepreneurship Happen','BEM2062 The Innovation and Entrepreneurship Mindset','BEA2002 Taxation','BEA2010 Managerial Accounting','BEA2017 Intermediate Management Accounting','BEA2019 Financial Accounting A','BEA2020 Financial Accounting B','BEE2020 Introduction to Econometric Theory','BEE2021 Policy Issues in the Global Economy','BEE2025 Microeconomics II','BEE2026 Macroeconomics II','BEE2027 Financial Markets and Decisions I','BEE2031 Econometrics','BEE2032 Applied Econometrics','BEE2037 Money and Banking','BEE2041 Data Science in Economics','BEE2044 Game Theory','BEF2012 Ethics and Corporate Governance','BEF2015 Quantitative Methods','BEF2016 FinTech in Investment Management','BEF2026 Equity and Fixed Income','BEM2007 Operations Management','BEM2016 Consumer Behaviour','BEM2021 Human Resource Management','BEM2025 Marketing Communications','BEM2033 Brands and Branding','BEM2048 International Business','BEM2066 Business Law for Managers','BEM2067 Leveraging Technologies for Business','BEM2068 AI, Business and Society'],
  'Final year':['BEM3047 Contemporary Leadership Issues','BEM3052 Managing Change and Crisis in Organisations','BEM3057 Employment Law for Managers','BEM3061 Business Ignition','BEM3090 Rethinking Innovation and Entrepreneurship','BEM3097 Regenerative Innovation for Climate Action','BEM3098 AI for Human-Centred Design','BEA3008 Finance for Managers','BEA3015 Corporate Law','BEA3017 Advanced Management Accounting','BEA3020 Advanced Financial Reporting','BEA3022 Auditing','BEA3026 Financial Modelling','BEE3015 Econometric Analysis','BEE3019 Law and Economics','BEE3032 Futures and Options','BEE3034 Financial Markets and Decisions 2','BEE3045 International Economics','BEE3049 Behaviour, Decisions and Markets','BEE3053 Economic Growth','BEE3066 Machine Learning for Economics','BEE3071 Applied Econometrics for Business','BEE3079 The Economics of Financial Crises','BEE3110 Blockchain, Money and Disruptive Payment Systems','BEM3062 Operations Analytics','BEM3064 Analytics and Visualisation for Managers and Consultants','BEM3065 Strategy','BUS3001 Dissertation']
};
function studyVisual(kind){
 const visuals={
 accounting:`<div class="study-visual"><strong>Accounting equation</strong><table><tr><th>Assets</th><th>=</th><th>Liabilities</th><th>+</th><th>Equity</th></tr><tr><td>Cash + receivables + PPE</td><td>=</td><td>Debt + payables</td><td>+</td><td>Owner capital + retained profit</td></tr></table></div>`,
 stats:`<div class="study-visual"><strong>Normal distribution</strong><svg viewBox="0 0 240 130"><line x1="20" y1="110" x2="225" y2="110"/><path d="M25 108 C70 105 78 34 120 25 C162 34 170 105 215 108" class="accent-line fill-none"/><line x1="120" y1="25" x2="120" y2="110" class="dash"/><text x="125" y="42">μ</text></svg></div>`,
 economics:`<div class="study-visual"><strong>Supply & demand</strong><svg viewBox="0 0 240 130"><line x1="30" y1="110" x2="225" y2="110"/><line x1="30" y1="110" x2="30" y2="10"/><line x1="45" y1="95" x2="205" y2="25" class="accent-line"/><line x1="45" y1="25" x2="205" y2="95" class="accent-line second"/><text x="188" y="30">S</text><text x="190" y="92">D</text></svg></div>`,
 finance:`<div class="study-visual"><strong>Time value of money</strong><table><tr><th>Formula</th><th>Use</th></tr><tr><td>PV = FV/(1+r)ⁿ</td><td>Discount future cash flow</td></tr><tr><td>FV = PV(1+r)ⁿ</td><td>Compound current value</td></tr><tr><td>NPV = Σ CFₜ/(1+r)ᵗ − I₀</td><td>Investment appraisal</td></tr></table></div>`,
 business:`<div class="study-visual"><strong>Stakeholder map</strong><table><tr><th></th><th>Low interest</th><th>High interest</th></tr><tr><th>High power</th><td>Keep satisfied</td><td>Manage closely</td></tr><tr><th>Low power</th><td>Monitor</td><td>Keep informed</td></tr></table></div>`,
 esg:`<div class="study-visual"><strong>ESG lens</strong><div class="esg-diagram"><span>E<br><small>Environment</small></span><span>S<br><small>Social</small></span><span>G<br><small>Governance</small></span></div></div>`,
 risk:`<div class="study-visual"><strong>Risk matrix</strong><table class="risk-table"><tr><th>Impact →</th><th>Low</th><th>Med</th><th>High</th></tr><tr><th>High likelihood</th><td>Med</td><td>High</td><td>Critical</td></tr><tr><th>Low likelihood</th><td>Low</td><td>Med</td><td>High</td></tr></table></div>`,
 project:`<div class="study-visual"><strong>Applied project flow</strong><div class="flow"><span>Question</span>→<span>Literature</span>→<span>Data</span>→<span>Method</span>→<span>Analysis</span>→<span>Conclusion</span></div></div>`,
 skills:`<div class="study-visual"><strong>Study cycle</strong><div class="flow"><span>Learn</span>→<span>Apply</span>→<span>Feedback</span>→<span>Reflect</span>→<span>Improve</span></div></div>`
 };return visuals[kind]||visuals.business;
}
function moduleCard([code,name,credits,summary,kind]){return `<article class="module-card"><div class="module-head"><div><small>${code} · ${credits} credits</small><h3>${name}</h3></div><button class="primary compact" data-module="${esc(code)}" data-module-name="${esc(name)}">Study notes</button></div><p>${summary}</p>${studyVisual(kind)}<div class="note-grid"><div><strong>Learn</strong><span>Concepts, definitions and theory</span></div><div><strong>Practise</strong><span>Worked examples and questions</span></div><div><strong>Revise</strong><span>Formula sheet, flashcards and exam plan</span></div></div></article>`}
function renderExeter(){
 if(!$('#exeterTitle'))return;
 $('#exeterTitle').textContent=`University of Exeter · ${exeterYear}`;
 if(exeterYear==='Study notes'){const all=[...EXETER_YEARS['Year 1'],...EXETER_YEARS['Year 2'],...EXETER_YEARS['Final year']];$('#exeterIntro').textContent='Core module study-note library with diagrams, tables, formulas and Merlin-generated revision packs.';$('#exeterLibrary').innerHTML=`<div class="module-list">${all.map(moduleCard).join('')}</div>`;bindModuleButtons();return}
 const mods=EXETER_YEARS[exeterYear]||[];const opts=EXETER_OPTIONALS[exeterYear]||[];$('#exeterIntro').textContent=`${mods.length} core modules in the CMK study library for ${exeterYear}.`;
 $('#exeterLibrary').innerHTML=`<div class="module-list">${mods.map(moduleCard).join('')}</div>${opts.length?`<details class="panel optional-catalog"><summary>Current optional-module catalogue (${opts.length})</summary><div class="optional-grid">${opts.map(x=>`<button data-optional-module="${esc(x)}">${esc(x)}</button>`).join('')}</div></details>`:''}`;bindModuleButtons();$$('[data-optional-module]').forEach(b=>b.onclick=()=>{$('#exeterQuestion').value=`Create a detailed University of Exeter study pack for ${b.dataset.optionalModule}: learning objectives, structured notes, key models/formulas, at least one table or diagram described clearly, worked example where relevant, common mistakes, flashcards and practice questions. Check the current official module description first.`;$('#exeterQuestion').focus()})
}
function bindModuleButtons(){$$('[data-module]').forEach(b=>b.onclick=()=>{$('#exeterQuestion').value=`Create a detailed study lesson for University of Exeter module ${b.dataset.module} ${b.dataset.moduleName}. Use the CMK module library as a starting point, then teach the topic I choose. Include definitions, formulas where relevant, a table or diagram, worked example, common mistakes, revision summary and practice question.`;$('#exeterQuestion').focus()})}
async function runExeter(refresh=false){const q=$('#exeterQuestion').value.trim();const out=$('#exeterOutput');out.innerHTML='<div class="panel">Merlin is preparing the Exeter study material…</div>';const p=refresh?`Check the current University of Exeter official page for BSc Finance: Business Management and report any changes to Year 1, Year 2 and final-year modules compared with this CMK library. Use only current official Exeter sources for module structure.`:`University of Exeter BSc Finance: Business Management study support, ${exeterYear}. ${q}`;try{const d=await api('/api/ask',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:p,mode:refresh?'research':'tutor',use_web:true})});out.innerHTML=`<div class="panel"><h2>${refresh?'Exeter library update':'Merlin Exeter Tutor'}</h2><p>${esc(d.answer)}</p>${d.sources?.length?`<div class="source-list">${d.sources.map(s=>`<a target="_blank" rel="noopener" href="${esc(s.url)}">↗ ${esc(s.title||s.url)}</a>`).join('')}</div>`:''}</div>`}catch(e){out.innerHTML=`<div class="panel">${esc(e.message)}</div>`}}

function renderTutor(){
  if(!$('#tutorTitle'))return;$('#tutorTitle').textContent=`Tutor mode · ${tutorSubject}`;$('#tutorIntro').textContent=`Merlin will teach ${tutorSubject} step by step, check your understanding and adapt the explanation to you.`;
  $('#tutorSubjectPills').innerHTML=TUTOR_SUBJECTS.map(s=>`<button class="subject-pill ${s===tutorSubject?'active':''}" data-tutor-subject="${esc(s)}">${esc(s)}</button>`).join('');
  $$('#tutorSubjectPills [data-tutor-subject]').forEach(b=>b.onclick=()=>{tutorSubject=b.dataset.tutorSubject;renderTutor()});
}
async function runTutor(practice=false){const q=$('#tutorQuestion').value.trim();if(!q&&!practice)return;$('#tutorOutput').innerHTML='<div class="panel">Merlin is preparing a step-by-step lesson…</div>';const prompt=practice?`Tutor me in ${tutorSubject}. Based on my current level and recent learning, give me one practice question, then wait for my attempt before revealing the full solution.`:`Tutor subject: ${tutorSubject}. Teach this step by step and check my understanding: ${q}`;try{const d=await api('/api/ask',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:prompt,user_id:userId,mode:'tutor',use_web:true})});$('#tutorOutput').innerHTML=`<div class="panel"><h2>Merlin Tutor</h2><p>${esc(d.answer)}</p></div>`}catch(e){$('#tutorOutput').innerHTML=`<div class="panel">${esc(e.message)}</div>`}}
function renderLegal(){
  if(!$('#legalTitle'))return;$('#legalTitle').textContent=`Legal · ${legalSection}`;
  $$('#legalTabs [data-legal-tab]').forEach(b=>b.classList.toggle('active',b.dataset.legalTab===legalSection));
  const items=LEGAL_LIBRARY[legalSection]||[];$('#legalLibrary').innerHTML=`<div class="legal-grid">${items.map(([t,d])=>`<button class="legal-card" data-legal-topic="${esc(t)}"><strong>${esc(t)}</strong><span>${esc(d)}</span></button>`).join('')}</div>`;
  $$('#legalLibrary [data-legal-topic]').forEach(b=>b.onclick=()=>{$('#legalQuestion').value=`Explain and help me with ${b.dataset.legalTopic}. `;$('#legalQuestion').focus()});
}
async function runLegal(deep=false){const q=$('#legalQuestion').value.trim();if(!q)return;$('#legalOutput').innerHTML='<div class="panel">Merlin is checking the legal issues and authorities…</div>';const prompt=`LEGAL SECTION: ${legalSection}. Analyse this rigorously. Identify jurisdiction/governing law if known; if not, say what must be confirmed. Distinguish contract wording from legal rules, identify evidence gaps and counterarguments, and do not invent authorities. ${q}`;try{const d=await api('/api/ask',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:prompt,user_id:userId,mode:deep?'research':'chat',use_web:true})});let src=d.sources?.length?`<h3>Sources</h3><div class="source-list">${d.sources.map(s=>`<a target="_blank" rel="noopener" href="${esc(s.url)}">↗ ${esc(s.title||s.url)}</a>`).join('')}</div>`:'';$('#legalOutput').innerHTML=`<div class="panel"><h2>Merlin Legal</h2><p>${esc(d.answer)}</p>${src}</div>`}catch(e){$('#legalOutput').innerHTML=`<div class="panel">${esc(e.message)}</div>`}}
document.addEventListener('DOMContentLoaded',()=>{renderTutor();renderMaths();renderExeter();renderLegal();$('#tutorStartBtn')&&($('#tutorStartBtn').onclick=()=>runTutor(false));$('#mathsTeachBtn')&&($('#mathsTeachBtn').onclick=()=>runMaths(false));$('#mathsPracticeBtn')&&($('#mathsPracticeBtn').onclick=()=>runMaths(true));$('#exeterTeachBtn')&&($('#exeterTeachBtn').onclick=()=>runExeter(false));$('#exeterRefreshBtn')&&($('#exeterRefreshBtn').onclick=()=>runExeter(true));$('#tutorPracticeBtn')&&($('#tutorPracticeBtn').onclick=()=>runTutor(true));$$('#legalTabs [data-legal-tab]').forEach(b=>b.onclick=()=>{legalSection=b.dataset.legalTab;renderLegal()});$('#legalAskBtn')&&($('#legalAskBtn').onclick=()=>runLegal(false));$('#legalResearchBtn')&&($('#legalResearchBtn').onclick=()=>runLegal(true))});
