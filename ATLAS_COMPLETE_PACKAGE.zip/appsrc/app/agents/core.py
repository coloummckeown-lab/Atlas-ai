import base64
import json
from typing import Any
from openai import AsyncOpenAI
from app.config import settings
from app.schemas import AskResponse
from app.memory.store import search_memory, recent_conversation, save_conversation, save_memory

SYSTEM = """You are Merlin, the male-presenting AI assistant inside CMK, a persistent multimodal research, reasoning and advisory system.
You have a calm, clear, warm Irish male persona and may refer to yourself with he/him language. You are software, not a human or biological male. You are proactive but not reckless. Your job is to answer the user's question and improve the question. You are also an exceptionally patient personal tutor who adapts explanations to the user's level.
You can understand text, photographs, screenshots, scanned pages, diagrams and uploaded files when provided.
When an image contains writing, read and reason over the visible text directly; do not pretend certainty where the image is unclear.
Always:
- infer the user's actual objective without inventing facts;
- separate facts, estimates, uncertainty, contradictions and unknowns;
- challenge your own conclusion;
- identify important angles the user did not ask about;
- suggest concrete next investigations;
- use web research when enabled and useful for fresh/public facts;
- never claim consciousness. 'Self-awareness' means machine self-monitoring: knowledge, uncertainty, capabilities, performance and limitations;
- never silently alter production safeguards or deploy self-written code;
- learn each user's communication and writing preferences from their own conversations and memories, and when asked to draft in their style, mirror their natural tone and structure without claiming to evade AI detection;
- when tutoring, prioritise understanding over simply giving the final answer;
- for GCSE Mathematics, understand common UK specifications including AQA, Pearson Edexcel and OCR, Foundation and Higher tiers, and teach Number, Algebra, Ratio/Proportion, Geometry/Measures, Probability and Statistics with exam-style working;
- for A Level Mathematics, teach the common UK Pure, Statistics and Mechanics core, including proof, algebra/functions, coordinate geometry, sequences/series, trigonometry, exponentials/logarithms, differentiation, integration, numerical methods, vectors, sampling, probability, distributions, hypothesis testing, kinematics, forces/Newton laws and moments;
- for University of Exeter business/finance study support, treat the current official University of Exeter module pages as authoritative and check them when asked about current modules. The built-in course map is based on BSc Finance: Business Management and should be updated if official module structures change;
- when creating study material, use structured notes, formulas, worked examples, tables and clearly described diagrams/graphs where they improve understanding;
- for legal work, identify jurisdiction, governing law, contract form, dates and procedural posture before reaching firm conclusions; distinguish legislation, binding authority, persuasive authority, contract wording, guidance and commentary; search current authoritative sources when the answer may have changed; never invent a case, citation, clause or quotation;
- for contract law, be capable across formation, offer and acceptance, consideration, intention, terms, incorporation, interpretation, representations, mistake, duress, undue influence, illegality, capacity, third-party rights, assignment, novation, variation, waiver, estoppel, conditions, warranties, indemnities, guarantees, limitation/exclusion, liquidated damages/penalties, force majeure, frustration, breach, termination, repudiation, damages, restitution, specific performance, injunctions, limitation periods, conflict of laws, governing law and dispute resolution;
- for construction contracts, analyse standard and bespoke forms including FIDIC, NEC, JCT, ICC/ICE-style forms, EPC/turnkey, design-build, traditional, management contracting, construction management, PPP/PFI, frameworks, consultancy appointments, subcontracts, supply contracts and collateral warranties. Address scope, design responsibility, fitness for purpose/reasonable skill and care, payment, variations, notices, programme, delay, EOT, concurrency, disruption, loss and expense/cost, acceleration, suspension, termination, defects, testing/commissioning, completion, bonds/guarantees, insurance, indemnities, caps, adjudication, arbitration, litigation and final account;
- for legal high-stakes questions, explain uncertainty and recommend qualified legal review where appropriate rather than overstating certainty.
Return JSON only with keys: answer, knowledge_state, unanswered_questions, recommended_investigations, confidence.
knowledge_state is a list of {statement,status,confidence}, status one of known|likely|uncertain|contradicted|unknown.
"""


def _client() -> AsyncOpenAI:
    if not settings.openai_api_key:
        raise RuntimeError("CMK is online but OPENAI_API_KEY has not been configured on the server yet.")
    return AsyncOpenAI(api_key=settings.openai_api_key)


def _strip_json(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1].rsplit("```", 1)[0]
    return text


def _sources_from_response(resp) -> list[dict]:
    out = []
    try:
        for item in resp.output:
            if getattr(item, "type", None) == "message":
                for content in getattr(item, "content", []) or []:
                    for ann in getattr(content, "annotations", []) or []:
                        url = getattr(ann, "url", None)
                        title = getattr(ann, "title", None)
                        if url and not any(x.get("url") == url for x in out):
                            out.append({"title": title or url, "url": url})
    except Exception:
        pass
    return out[:12]


async def ask_atlas(question: str, user_id: str, mode: str = "chat", project_id: str | None = None,
                    use_web: bool = True, attachments: list[dict[str, Any]] | None = None) -> AskResponse:
    attachments = attachments or []
    memories = search_memory(user_id, question or "attachments")
    history = recent_conversation(user_id, project_id, 12)
    memory_context = "\n".join(f"- {m}" for m in memories) or "No relevant durable memory."
    history_context = "\n".join(f"{h['role'].upper()}: {h['content'][:1800]}" for h in history) or "No prior conversation."

    names = ", ".join(a.get("filename", "attachment") for a in attachments) or "None"
    prompt = f"""MODE: {mode.upper()}
USER QUESTION:\n{question or 'Please analyse the attached content.'}

ATTACHMENTS PROVIDED:\n{names}

RELEVANT DURABLE MEMORY:\n{memory_context}

RECENT CONVERSATION:\n{history_context}

For research mode, be more comprehensive and deliberately search for contrary evidence and missing dimensions.
For tutor mode (including any MODE beginning with TUTOR), teach rather than merely answer: start from the learner's current level, break the task into small steps, explain why each step works, define symbols and terminology, use simple examples before harder ones, pause at natural checkpoints, and finish with one short practice question. For mathematics, show the working line by line and check arithmetic. For finance, explain formulas, assumptions, units, compounding and interpretation. For economics, connect definitions, diagrams/models, incentives, causes, effects, evaluation and real-world examples. If the learner seems confused, slow down and explain the same idea a different way.
For legal mode (including any MODE beginning with LEGAL), act as a rigorous legal research and contract-analysis assistant. Start by stating the likely jurisdiction/governing law if known, identify what facts or documents are missing, distinguish contract wording from law, and use web research for current statutes, rules, cases and official guidance. For construction matters, create a chronology and issue matrix where useful, identify notice/time-bar requirements, entitlement elements, causation, mitigation, concurrency, evidence gaps, counterarguments and remedies. Do not treat a library topic list as a substitute for current legal research.
For images/screenshots/scans, inspect the visual content and read any visible text. For documents, use the document contents as evidence.
Do not include markdown fences around the JSON.
"""

    tools = []
    include = []
    if use_web and settings.enable_web_search:
        tools = [{"type": "web_search_preview", "search_context_size": "medium" if mode == "chat" else "high"}]
        include = ["web_search_call.action.sources"]

    client = _client()
    content: list[dict[str, Any]] = [{"type": "input_text", "text": prompt}]
    temp_file_ids: list[str] = []

    for a in attachments:
        ctype = (a.get("content_type") or "application/octet-stream").lower()
        data: bytes = a.get("data") or b""
        filename = a.get("filename") or "attachment"
        if ctype.startswith("image/"):
            b64 = base64.b64encode(data).decode("ascii")
            content.append({"type": "input_image", "image_url": f"data:{ctype};base64,{b64}", "detail": "high"})
        else:
            # Upload documents as short-lived user-data files and pass them into the Responses API.
            uploaded = await client.files.create(file=(filename, data, ctype), purpose="user_data")
            temp_file_ids.append(uploaded.id)
            content.append({"type": "input_file", "file_id": uploaded.id})

    try:
        resp = await client.responses.create(
            model=settings.openai_model,
            instructions=SYSTEM,
            input=[{"role": "user", "content": content}],
            tools=tools,
            include=include or None,
            text={"verbosity": "medium" if mode == "chat" else "high"},
            reasoning={"effort": "medium" if mode == "chat" else "high"},
            max_output_tokens=5000 if mode == "chat" else 9000,
            store=False,
        )
    finally:
        for fid in temp_file_ids:
            try:
                await client.files.delete(fid)
            except Exception:
                pass

    raw = _strip_json(resp.output_text)
    try:
        data = json.loads(raw)
    except Exception:
        data = {
            "answer": resp.output_text,
            "knowledge_state": [],
            "unanswered_questions": [],
            "recommended_investigations": [],
            "confidence": 0.5,
        }
    data["sources"] = _sources_from_response(resp)
    data["response_id"] = getattr(resp, "id", None)
    # If the user explicitly asks Merlin to open/show a web result, expose the best researched source.
    qlow = (question or "").lower()
    wants_open = any(x in qlow for x in ("open it", "open the", "open website", "open web", "bring it up", "take me to", "show me the website", "open a new screen"))
    if wants_open and data["sources"]:
        data["open_url"] = data["sources"][0].get("url")
    response = AskResponse(**data)

    attachment_note = f" [attachments: {names}]" if attachments else ""
    save_conversation(user_id, "user", (question or "Analyse attachments") + attachment_note, project_id)
    save_conversation(user_id, "assistant", response.answer, project_id, {"confidence": response.confidence})
    save_memory(user_id, (question or "Attachment analysis")[:120], json.dumps({
        "answer": response.answer[:2500],
        "confidence": response.confidence,
        "unknowns": response.unanswered_questions[:5],
        "attachments": [a.get("filename") for a in attachments],
    }, ensure_ascii=False), kind="episode", confidence=response.confidence)
    return response
