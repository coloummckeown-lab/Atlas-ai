import base64
import hashlib
import hmac
import json
import secrets
import smtplib
import time
from email.message import EmailMessage
from urllib.parse import quote

from app.config import settings
from app.memory.store import (
    get_auth_password_hash,
    get_user_account,
    create_user_account,
    update_user_password,
)

PBKDF2_ITERS = 310_000
SESSION_SECONDS = 60 * 60 * 24 * 30
RESET_SECONDS = 60 * 30


def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, PBKDF2_ITERS)
    return 'pbkdf2_sha256${}${}${}'.format(
        PBKDF2_ITERS,
        base64.urlsafe_b64encode(salt).decode().rstrip('='),
        base64.urlsafe_b64encode(digest).decode().rstrip('='),
    )


def verify_password(password: str, encoded: str) -> bool:
    try:
        scheme, iters_s, salt_s, digest_s = encoded.split('$', 3)
        if scheme != 'pbkdf2_sha256':
            return False
        def dec(v: str) -> bytes:
            return base64.urlsafe_b64decode(v + '=' * (-len(v) % 4))
        salt = dec(salt_s)
        expected = dec(digest_s)
        actual = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, int(iters_s))
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


def bootstrap_admin() -> None:
    username = settings.cmk_admin_username.strip()
    if not username or get_user_account(username):
        return
    encoded = get_auth_password_hash(username) or settings.cmk_admin_password_hash
    if encoded:
        create_user_account(
            username=username,
            email=settings.cmk_reset_email.strip(),
            password_hash=encoded,
            role='owner',
            must_change_password=True,
        )


def authenticate(username: str, password: str) -> dict | None:
    account = get_user_account(username)
    if not account or not account.get('enabled', True):
        return None
    return account if verify_password(password, account['password_hash']) else None


def _sign(payload: dict) -> str:
    raw = json.dumps(payload, separators=(',', ':'), sort_keys=True).encode()
    body = base64.urlsafe_b64encode(raw).decode().rstrip('=')
    sig = hmac.new(settings.cmk_session_secret.encode(), body.encode(), hashlib.sha256).digest()
    return body + '.' + base64.urlsafe_b64encode(sig).decode().rstrip('=')


def _verify(token: str, purpose: str) -> dict | None:
    try:
        body, sig_s = token.split('.', 1)
        expected = hmac.new(settings.cmk_session_secret.encode(), body.encode(), hashlib.sha256).digest()
        got = base64.urlsafe_b64decode(sig_s + '=' * (-len(sig_s) % 4))
        if not hmac.compare_digest(expected, got):
            return None
        raw = base64.urlsafe_b64decode(body + '=' * (-len(body) % 4))
        data = json.loads(raw)
        if data.get('purpose') != purpose or int(data.get('exp', 0)) < int(time.time()):
            return None
        return data
    except Exception:
        return None


def make_session(username: str) -> str:
    return _sign({'sub': username, 'purpose': 'session', 'exp': int(time.time()) + SESSION_SECONDS})


def session_user(token: str | None) -> str | None:
    if not token:
        return None
    data = _verify(token, 'session')
    return data.get('sub') if data else None


def make_reset_token(username: str) -> str:
    return _sign({'sub': username, 'purpose': 'reset', 'exp': int(time.time()) + RESET_SECONDS})


def verify_reset_token(token: str) -> str | None:
    data = _verify(token, 'reset')
    return data.get('sub') if data else None


def change_password(username: str, new_password: str) -> None:
    update_user_password(username, hash_password(new_password), must_change_password=False)


def send_reset_email(username: str) -> bool:
    account = get_user_account(username)
    if not account:
        return False
    recipient = (account.get('email') or '').strip()
    if not (recipient and settings.smtp_host and settings.smtp_username and settings.smtp_password):
        return False
    token = make_reset_token(username)
    base = settings.cmk_public_url.rstrip('/')
    link = f"{base}/?reset_token={quote(token)}"
    msg = EmailMessage()
    msg['Subject'] = 'CMK password reset'
    msg['From'] = settings.smtp_from or settings.smtp_username
    msg['To'] = recipient
    msg.set_content(
        'A password reset was requested for CMK.\n\n'
        f'Use this one-time link within 30 minutes:\n{link}\n\n'
        'If you did not request this, ignore this email. CMK never emails or stores your password in plain text.'
    )
    with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=20) as server:
        if settings.smtp_use_tls:
            server.starttls()
        server.login(settings.smtp_username, settings.smtp_password)
        server.send_message(msg)
    return True
