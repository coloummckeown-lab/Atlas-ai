from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    openai_api_key: str = ""
    openai_model: str = "gpt-5.6-sol"
    fast_model: str = "gpt-5.6-luna"
    database_url: str = ""
    atlas_name: str = "CMK"
    enable_web_search: bool = True
    enable_self_evolution: bool = True
    trace_sensitive_data: bool = False
    cmk_admin_username: str = ""
    cmk_admin_password_hash: str = ""
    cmk_reset_email: str = ""
    cmk_session_secret: str = ""
    cmk_public_url: str = "https://atlas-ai-app.onrender.com"
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    smtp_from: str = ""
    smtp_use_tls: bool = True

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
