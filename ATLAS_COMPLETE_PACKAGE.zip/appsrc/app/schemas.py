from typing import Literal
from pydantic import BaseModel, Field


class AskRequest(BaseModel):
    question: str = Field(min_length=1, max_length=20000)
    user_id: str = "owner"
    mode: Literal["chat", "research", "tutor"] = "chat"
    project_id: str | None = None
    use_web: bool = True


class KnowledgeItem(BaseModel):
    statement: str
    status: Literal["known", "likely", "uncertain", "contradicted", "unknown"]
    confidence: float = Field(ge=0, le=1)


class AskResponse(BaseModel):
    answer: str
    knowledge_state: list[KnowledgeItem] = []
    unanswered_questions: list[str] = []
    recommended_investigations: list[str] = []
    sources: list[dict] = []
    confidence: float = 0.5
    response_id: str | None = None
    open_url: str | None = None


class MemoryCreate(BaseModel):
    user_id: str = "owner"
    kind: str = "fact"
    topic: str
    content: str
    confidence: float = 1.0


class ProjectCreate(BaseModel):
    user_id: str = "owner"
    name: str
    description: str = ""
    profile: dict = {}


class ImprovementProposal(BaseModel):
    title: str
    problem: str
    rationale: str
    target_files: list[str]
    proposed_changes: str
    test_plan: list[str]
    risk: Literal["low", "medium", "high"] = "medium"
    expected_benefit: str
    requires_human_approval: bool = True


class EvolutionRequest(BaseModel):
    user_id: str = "owner"
    objective: str = "Review CMK and propose the highest-value safe improvement."


class EvolutionApprovalRequest(BaseModel):
    user_id: str = "owner"
    proposal_id: int
    approve: bool = True

class EvolutionDeployApprovalRequest(BaseModel):
    user_id: str = "owner"
    proposal_id: int
    approve: bool = True


class ProjectProfileUpdate(BaseModel):
    profile: dict = {}
