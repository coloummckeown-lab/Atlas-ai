import json
import sqlite3
from pathlib import Path
from typing import Any

from app.config import settings

DB_PATH = Path(__file__).resolve().parents[2] / "atlas_memory.db"


def _is_pg() -> bool:
    return bool(settings.database_url and settings.database_url.startswith(("postgres://", "postgresql://")))


def _pg_connect():
    import psycopg
    return psycopg.connect(settings.database_url)


def init_db() -> None:
    statements = [
        """CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
            user_id TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'fact',
            topic TEXT NOT NULL, content TEXT NOT NULL,
            confidence DOUBLE PRECISION NOT NULL DEFAULT 1.0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""",
        """CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
            user_id TEXT NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""",
        """CREATE TABLE IF NOT EXISTS project_profiles (
            project_id TEXT NOT NULL, user_id TEXT NOT NULL, data TEXT NOT NULL DEFAULT '{}',
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(project_id,user_id))""",
        """CREATE TABLE IF NOT EXISTS conversations (
            id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
            user_id TEXT NOT NULL, project_id TEXT, role TEXT NOT NULL, content TEXT NOT NULL,
            metadata TEXT NOT NULL DEFAULT '{}', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""",
        """CREATE TABLE IF NOT EXISTS evolution_proposals (
            id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
            user_id TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'proposed', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""",
        """CREATE TABLE IF NOT EXISTS auth_state (
            username TEXT PRIMARY KEY, password_hash TEXT NOT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""",
        """CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY, email TEXT NOT NULL DEFAULT '',
            password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user',
            must_change_password BOOLEAN NOT NULL DEFAULT FALSE,
            enabled BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""",
    ]
    if _is_pg():
        with _pg_connect() as con:
            with con.cursor() as cur:
                for s in statements:
                    cur.execute(s)
        return

    sqlite_statements = [s.replace("INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY", "INTEGER PRIMARY KEY AUTOINCREMENT")
                         .replace("DOUBLE PRECISION", "REAL") for s in statements]
    with sqlite3.connect(DB_PATH) as con:
        for s in sqlite_statements:
            con.execute(s)


def _fetchall(sql_pg: str, sql_sqlite: str, params: tuple[Any, ...] = ()) -> list[dict]:
    if _is_pg():
        with _pg_connect() as con, con.cursor() as cur:
            cur.execute(sql_pg, params)
            cols = [d.name for d in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]
    with sqlite3.connect(DB_PATH) as con:
        con.row_factory = sqlite3.Row
        return [dict(r) for r in con.execute(sql_sqlite, params).fetchall()]


def save_memory(user_id: str, topic: str, content: str, kind: str = "fact", confidence: float = 1.0) -> None:
    if _is_pg():
        with _pg_connect() as con, con.cursor() as cur:
            cur.execute("INSERT INTO memories(user_id,kind,topic,content,confidence) VALUES(%s,%s,%s,%s,%s)",
                        (user_id, kind, topic, content, confidence))
    else:
        with sqlite3.connect(DB_PATH) as con:
            con.execute("INSERT INTO memories(user_id,kind,topic,content,confidence) VALUES(?,?,?,?,?)",
                        (user_id, kind, topic, content, confidence))


def list_memories(user_id: str, limit: int = 100) -> list[dict]:
    return _fetchall(
        "SELECT id,kind,topic,content,confidence,created_at FROM memories WHERE user_id=%s ORDER BY id DESC LIMIT %s",
        "SELECT id,kind,topic,content,confidence,created_at FROM memories WHERE user_id=? ORDER BY id DESC LIMIT ?",
        (user_id, limit),
    )


def search_memory(user_id: str, query: str, limit: int = 12) -> list[str]:
    rows = list_memories(user_id, 300)
    terms = [t.lower().strip(".,!?;:") for t in query.split() if len(t) > 3][:12]
    scored = []
    for row in rows:
        text = f"{row['topic']} {row['content']}".lower()
        score = sum(text.count(term) for term in terms)
        if score:
            scored.append((score, row))
    scored.sort(key=lambda x: (x[0], str(x[1].get("created_at", ""))), reverse=True)
    return [f"[{r['kind']}] {r['topic']}: {r['content']}" for _, r in scored[:limit]]


def save_conversation(user_id: str, role: str, content: str, project_id: str | None = None, metadata: dict | None = None) -> None:
    meta = json.dumps(metadata or {}, ensure_ascii=False)
    if _is_pg():
        with _pg_connect() as con, con.cursor() as cur:
            cur.execute("INSERT INTO conversations(user_id,project_id,role,content,metadata) VALUES(%s,%s,%s,%s,%s)",
                        (user_id, project_id, role, content, meta))
    else:
        with sqlite3.connect(DB_PATH) as con:
            con.execute("INSERT INTO conversations(user_id,project_id,role,content,metadata) VALUES(?,?,?,?,?)",
                        (user_id, project_id, role, content, meta))


def recent_conversation(user_id: str, project_id: str | None = None, limit: int = 14) -> list[dict]:
    if project_id:
        return _fetchall(
            "SELECT role,content,metadata,created_at FROM conversations WHERE user_id=%s AND project_id=%s ORDER BY id DESC LIMIT %s",
            "SELECT role,content,metadata,created_at FROM conversations WHERE user_id=? AND project_id=? ORDER BY id DESC LIMIT ?",
            (user_id, project_id, limit),
        )[::-1]
    return _fetchall(
        "SELECT role,content,metadata,created_at FROM conversations WHERE user_id=%s ORDER BY id DESC LIMIT %s",
        "SELECT role,content,metadata,created_at FROM conversations WHERE user_id=? ORDER BY id DESC LIMIT ?",
        (user_id, limit),
    )[::-1]


def create_project(user_id: str, name: str, description: str = "", profile: dict | None = None) -> dict:
    if _is_pg():
        with _pg_connect() as con, con.cursor() as cur:
            cur.execute("INSERT INTO projects(user_id,name,description) VALUES(%s,%s,%s) RETURNING id", (user_id, name, description))
            pid = cur.fetchone()[0]
    else:
        with sqlite3.connect(DB_PATH) as con:
            cur = con.execute("INSERT INTO projects(user_id,name,description) VALUES(?,?,?)", (user_id, name, description))
            pid = cur.lastrowid
    if profile is not None:
        save_project_profile(user_id, str(pid), profile)
    return {"id": pid, "name": name, "description": description, "profile": profile or {}}


def save_project_profile(user_id: str, project_id: str, profile: dict) -> None:
    payload=json.dumps(profile or {}, ensure_ascii=False)
    if _is_pg():
        with _pg_connect() as con, con.cursor() as cur:
            cur.execute("INSERT INTO project_profiles(project_id,user_id,data) VALUES(%s,%s,%s) ON CONFLICT(project_id,user_id) DO UPDATE SET data=EXCLUDED.data, updated_at=CURRENT_TIMESTAMP", (str(project_id),user_id,payload))
    else:
        with sqlite3.connect(DB_PATH) as con:
            con.execute("INSERT INTO project_profiles(project_id,user_id,data) VALUES(?,?,?) ON CONFLICT(project_id,user_id) DO UPDATE SET data=excluded.data, updated_at=CURRENT_TIMESTAMP", (str(project_id),user_id,payload))

def get_project_profile(user_id: str, project_id: str) -> dict:
    rows=_fetchall("SELECT data FROM project_profiles WHERE user_id=%s AND project_id=%s", "SELECT data FROM project_profiles WHERE user_id=? AND project_id=?", (user_id,str(project_id)))
    if not rows:return {}
    try:return json.loads(rows[0]["data"] or "{}")
    except:return {}

def list_projects(user_id: str) -> list[dict]:
    items = _fetchall(
        "SELECT id,name,description,created_at FROM projects WHERE user_id=%s ORDER BY id DESC",
        "SELECT id,name,description,created_at FROM projects WHERE user_id=? ORDER BY id DESC",
        (user_id,),
    )
    for item in items:
        item["profile"] = get_project_profile(user_id, str(item["id"]))
    return items


def save_evolution_proposal(user_id: str, title: str, body: dict) -> None:
    payload = json.dumps(body, ensure_ascii=False)
    if _is_pg():
        with _pg_connect() as con, con.cursor() as cur:
            cur.execute("INSERT INTO evolution_proposals(user_id,title,body) VALUES(%s,%s,%s)", (user_id, title, payload))
    else:
        with sqlite3.connect(DB_PATH) as con:
            con.execute("INSERT INTO evolution_proposals(user_id,title,body) VALUES(?,?,?)", (user_id, title, payload))


def list_evolution_proposals(user_id: str) -> list[dict]:
    rows = _fetchall(
        "SELECT id,title,body,status,created_at FROM evolution_proposals WHERE user_id=%s ORDER BY id DESC LIMIT 50",
        "SELECT id,title,body,status,created_at FROM evolution_proposals WHERE user_id=? ORDER BY id DESC LIMIT 50",
        (user_id,),
    )
    for r in rows:
        try: r["body"] = json.loads(r["body"])
        except Exception: pass
    return rows


def get_auth_password_hash(username: str) -> str:
    rows = _fetchall(
        "SELECT password_hash FROM auth_state WHERE username=%s LIMIT 1",
        "SELECT password_hash FROM auth_state WHERE username=? LIMIT 1",
        (username,),
    )
    return rows[0]["password_hash"] if rows else ""


def set_auth_password_hash(username: str, password_hash: str) -> None:
    if _is_pg():
        with _pg_connect() as con, con.cursor() as cur:
            cur.execute(
                "INSERT INTO auth_state(username,password_hash) VALUES(%s,%s) "
                "ON CONFLICT(username) DO UPDATE SET password_hash=EXCLUDED.password_hash, updated_at=CURRENT_TIMESTAMP",
                (username, password_hash),
            )
    else:
        with sqlite3.connect(DB_PATH) as con:
            con.execute(
                "INSERT INTO auth_state(username,password_hash) VALUES(?,?) "
                "ON CONFLICT(username) DO UPDATE SET password_hash=excluded.password_hash, updated_at=CURRENT_TIMESTAMP",
                (username, password_hash),
            )


def get_evolution_proposal(proposal_id: int, user_id: str) -> dict | None:
    rows = _fetchall(
        "SELECT id,title,body,status,created_at FROM evolution_proposals WHERE id=%s AND user_id=%s LIMIT 1",
        "SELECT id,title,body,status,created_at FROM evolution_proposals WHERE id=? AND user_id=? LIMIT 1",
        (proposal_id, user_id),
    )
    if not rows:
        return None
    row = rows[0]
    try: row["body"] = json.loads(row["body"])
    except Exception: pass
    return row


def update_evolution_proposal(proposal_id: int, user_id: str, status: str, body: dict | None = None) -> None:
    payload = json.dumps(body, ensure_ascii=False) if body is not None else None
    if _is_pg():
        with _pg_connect() as con, con.cursor() as cur:
            if payload is None:
                cur.execute("UPDATE evolution_proposals SET status=%s WHERE id=%s AND user_id=%s", (status, proposal_id, user_id))
            else:
                cur.execute("UPDATE evolution_proposals SET status=%s, body=%s WHERE id=%s AND user_id=%s", (status, payload, proposal_id, user_id))
    else:
        with sqlite3.connect(DB_PATH) as con:
            if payload is None:
                con.execute("UPDATE evolution_proposals SET status=? WHERE id=? AND user_id=?", (status, proposal_id, user_id))
            else:
                con.execute("UPDATE evolution_proposals SET status=?, body=? WHERE id=? AND user_id=?", (status, payload, proposal_id, user_id))


def get_user_account(username: str) -> dict | None:
    rows = _fetchall(
        "SELECT username,email,password_hash,role,must_change_password,enabled,created_at FROM users WHERE username=%s LIMIT 1",
        "SELECT username,email,password_hash,role,must_change_password,enabled,created_at FROM users WHERE username=? LIMIT 1",
        (username,),
    )
    return rows[0] if rows else None


def create_user_account(username: str, email: str, password_hash: str, role: str = "user", must_change_password: bool = False) -> dict:
    if _is_pg():
        with _pg_connect() as con, con.cursor() as cur:
            cur.execute(
                "INSERT INTO users(username,email,password_hash,role,must_change_password,enabled) VALUES(%s,%s,%s,%s,%s,TRUE)",
                (username, email, password_hash, role, must_change_password),
            )
    else:
        with sqlite3.connect(DB_PATH) as con:
            con.execute(
                "INSERT INTO users(username,email,password_hash,role,must_change_password,enabled) VALUES(?,?,?,?,?,1)",
                (username, email, password_hash, role, int(bool(must_change_password))),
            )
    return {"username": username, "email": email, "role": role, "must_change_password": bool(must_change_password), "enabled": True}


def update_user_password(username: str, password_hash: str, must_change_password: bool = False) -> None:
    if _is_pg():
        with _pg_connect() as con, con.cursor() as cur:
            cur.execute(
                "UPDATE users SET password_hash=%s,must_change_password=%s,updated_at=CURRENT_TIMESTAMP WHERE username=%s",
                (password_hash, must_change_password, username),
            )
    else:
        with sqlite3.connect(DB_PATH) as con:
            con.execute(
                "UPDATE users SET password_hash=?,must_change_password=?,updated_at=CURRENT_TIMESTAMP WHERE username=?",
                (password_hash, int(bool(must_change_password)), username),
            )


def list_user_accounts() -> list[dict]:
    return _fetchall(
        "SELECT username,email,role,must_change_password,enabled,created_at FROM users ORDER BY created_at ASC",
        "SELECT username,email,role,must_change_password,enabled,created_at FROM users ORDER BY created_at ASC",
    )
