from app.evolution.engine import evolution_contract


def test_live_self_modification_is_disabled():
    policy = evolution_contract()
    assert policy["can_propose_patch"] is True
    assert policy["can_modify_live_production_without_approval"] is False
    assert policy["can_disable_safety_gates"] is False
