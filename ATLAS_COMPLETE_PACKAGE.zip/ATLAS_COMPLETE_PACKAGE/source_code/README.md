# ATLAS V1.1 — Installable Web App

ATLAS is a persistent AI research/advisory system designed to answer questions, identify uncertainty, challenge its own analysis, propose further investigations, remember useful context, and evolve through controlled code-improvement proposals.

## What this version adds

- Installable Progressive Web App (PWA)
- Mobile-first chat interface
- Works on iPhone/iPad and desktop browsers from one codebase
- ATLAS knowledge-state panel
- Clickable recommended investigations
- Local device identity for persistent user memory
- FastAPI serves both the API and app UI
- Offline shell via a service worker

## Architecture

- FastAPI API + web server
- OpenAI Agents SDK orchestration
- Researcher agent
- Critic agent
- Expansion agent
- ATLAS orchestrator
- SQLite development memory
- Evolution-policy boundary
- Pytest safety test
- HTML/CSS/JavaScript PWA frontend

## Controlled evolution model

ATLAS may:
1. inspect its source code;
2. analyse traces, failures, user corrections and evaluation results;
3. propose a code patch;
4. create/update tests in a disposable branch/worktree;
5. run tests in an isolated sandbox;
6. compare the candidate with the current baseline;
7. request approval for promotion.

ATLAS may **not** silently overwrite the running production application, disable its own gates, or expose secrets to candidate code.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
cp .env.example .env
# Put your OpenAI API key in .env
uvicorn app.main:app --reload --host 0.0.0.0
```

Open on the same computer:

- ATLAS app: http://127.0.0.1:8000
- API docs: http://127.0.0.1:8000/docs
- Health: http://127.0.0.1:8000/health

## Testing on your phone on the same Wi‑Fi

Run ATLAS with `--host 0.0.0.0`, find your computer's local IP address, and open:

`http://YOUR-COMPUTER-IP:8000`

This is useful for development. Full PWA installation/service-worker behaviour normally requires HTTPS, so deploy ATLAS to an HTTPS host before installing it permanently on your iPhone Home Screen.

## Install on iPhone after deployment

1. Open the deployed HTTPS ATLAS address in Safari.
2. Tap **Share**.
3. Tap **Add to Home Screen**.
4. Choose **Add**.

ATLAS then launches in a standalone app-style window.

## Install on a computer

Open the deployed ATLAS URL in Chrome or Edge and use the browser's **Install app** option. Safari on macOS also supports adding compatible web apps to the Dock on recent macOS releases.

## Important security rule

Never put the OpenAI API key in `app.js`, HTML, React/Next.js client code, or an iPhone build. Keep it only on the server in environment variables/secrets. The phone talks to your ATLAS backend; the backend talks to the model API.

## Next development steps

### V1.2
- login/account system so all devices share one identity
- PostgreSQL + pgvector cloud memory
- conversation history
- web/file research tools with citations
- streaming answers
- research-tree UI

### V1.3
- candidate patch generator
- Git worktrees / isolated test environment
- baseline-vs-candidate evaluation
- human approval screen for ATLAS evolution

### V2
- knowledge graph
- native iOS/Android wrapper if desired
- voice
- documents/email integrations
- scheduled investigations
