from pathlib import Path
from app.schemas import ImprovementProposal

ROOT = Path(__file__).resolve().parents[2]
PROTECTED = {".env", ".git", "atlas_memory.db"}


class EvolutionPolicy:
    """Hard boundary between self-review and live self-modification."""

    allow_code_proposals: bool = True
    auto_deploy: bool = False
    require_tests: bool = True
    require_human_approval: bool = True


def source_manifest() -> list[str]:
    files = []
    for p in ROOT.rglob("*.py"):
        if not any(part in PROTECTED for part in p.parts):
            files.append(str(p.relative_to(ROOT)))
    return sorted(files)


def validate_proposal(proposal: ImprovementProposal) -> tuple[bool, list[str]]:
    reasons: list[str] = []
    if not proposal.requires_human_approval:
        reasons.append("All V1 code changes must require human approval.")
    if not proposal.test_plan:
        reasons.append("Every code change needs a test plan.")
    if any(f.startswith("/") or ".." in f for f in proposal.target_files):
        reasons.append("Target files must stay inside the ATLAS repository.")
    return (not reasons, reasons)


def evolution_contract() -> dict:
    return {
        "can_read_own_source": True,
        "can_propose_patch": True,
        "can_generate_tests": True,
        "can_run_tests_in_sandbox": True,
        "can_measure_candidate_vs_baseline": True,
        "can_modify_live_production_without_approval": False,
        "can_disable_safety_gates": False,
        "can_access_secrets_for_self_modification": False,
    }
