import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parents[2] / "atlas_memory.db"


def init_db() -> None:
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            topic TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
        """)


def save_memory(user_id: str, topic: str, content: str) -> None:
    with sqlite3.connect(DB_PATH) as con:
        con.execute(
            "INSERT INTO memories(user_id, topic, content) VALUES (?, ?, ?)",
            (user_id, topic, content),
        )


def search_memory(user_id: str, query: str, limit: int = 8) -> list[str]:
    # V1 uses lexical search. V2 replaces this with embeddings + pgvector.
    terms = [t.lower() for t in query.split() if len(t) > 3][:8]
    if not terms:
        return []
    with sqlite3.connect(DB_PATH) as con:
        rows = con.execute(
            "SELECT content FROM memories WHERE user_id=? ORDER BY id DESC LIMIT 200",
            (user_id,),
        ).fetchall()
    scored = []
    for (content,) in rows:
        score = sum(term in content.lower() for term in terms)
        if score:
            scored.append((score, content))
    scored.sort(reverse=True, key=lambda x: x[0])
    return [c for _, c in scored[:limit]]
