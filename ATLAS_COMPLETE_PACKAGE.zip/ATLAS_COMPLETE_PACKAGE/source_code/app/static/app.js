const messages = document.getElementById('messages');
const form = document.getElementById('askForm');
const question = document.getElementById('question');
const send = document.getElementById('send');
const statusEl = document.getElementById('status');
const insightPanel = document.getElementById('insightPanel');
const knowledgeState = document.getElementById('knowledgeState');
const nextSteps = document.getElementById('nextSteps');

const userId = localStorage.getItem('atlas_user_id') || crypto.randomUUID();
localStorage.setItem('atlas_user_id', userId);

function addMessage(role, text) {
  const article = document.createElement('article');
  article.className = `message ${role}`;
  const avatar = document.createElement('div');
  avatar.className = 'avatar';
  avatar.textContent = role === 'user' ? 'Y' : 'A';
  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  const p = document.createElement('p');
  p.textContent = text;
  bubble.appendChild(p);
  article.append(avatar, bubble);
  messages.appendChild(article);
  window.scrollTo({top: document.body.scrollHeight, behavior: 'smooth'});
}

function renderInsights(data) {
  knowledgeState.innerHTML = '';
  nextSteps.innerHTML = '';

  for (const item of data.knowledge_state || []) {
    const row = document.createElement('div');
    row.className = 'kitem';
    row.innerHTML = `<span class="badge"></span><span></span><span class="conf"></span>`;
    row.children[0].textContent = item.status;
    row.children[1].textContent = item.statement;
    row.children[2].textContent = `${Math.round((item.confidence || 0) * 100)}%`;
    knowledgeState.appendChild(row);
  }

  const steps = data.recommended_investigations || [];
  if (steps.length) {
    const holder = document.createElement('div');
    holder.className = 'steps';
    const title = document.createElement('strong');
    title.textContent = 'Recommended next investigations';
    holder.appendChild(title);
    steps.forEach(step => {
      const btn = document.createElement('button');
      btn.className = 'step';
      btn.type = 'button';
      btn.textContent = step;
      btn.onclick = () => { question.value = step; question.focus(); };
      holder.appendChild(btn);
    });
    nextSteps.appendChild(holder);
  }

  insightPanel.classList.toggle('hidden', !(data.knowledge_state?.length || steps.length));
}

async function health() {
  try {
    const res = await fetch('/health');
    if (!res.ok) throw new Error('offline');
    statusEl.textContent = 'ATLAS online';
    statusEl.classList.add('ok');
  } catch {
    statusEl.textContent = 'Offline';
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const text = question.value.trim();
  if (!text) return;
  addMessage('user', text);
  question.value = '';
  send.disabled = true;
  send.textContent = 'Thinking…';
  insightPanel.classList.add('hidden');

  try {
    const res = await fetch('/ask', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({question: text, user_id: userId})
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'ATLAS request failed');
    addMessage('atlas', data.answer);
    renderInsights(data);
  } catch (err) {
    addMessage('atlas', `I couldn't complete that request: ${err.message}`);
  } finally {
    send.disabled = false;
    send.textContent = 'Send';
    question.focus();
  }
});

question.addEventListener('input', () => {
  question.style.height = 'auto';
  question.style.height = `${Math.min(question.scrollHeight, 180)}px`;
});

if ('serviceWorker' in navigator) navigator.serviceWorker.register('/service-worker.js');
health();
