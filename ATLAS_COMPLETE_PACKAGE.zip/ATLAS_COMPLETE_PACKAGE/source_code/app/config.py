from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    openai_api_key: str = ""
    openai_model: str = "gpt-5.6"
    atlas_allow_code_proposals: bool = True
    atlas_auto_deploy: bool = False

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
