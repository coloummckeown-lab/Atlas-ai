import json
from agents import Agent, Runner
from app.config import settings
from app.schemas import AskResponse
from app.memory.store import search_memory, save_memory

MODEL = settings.openai_model

researcher = Agent(
    name="Researcher",
    model=MODEL,
    instructions=(
        "Investigate the user's question. Identify material facts, missing evidence, "
        "alternative explanations, and areas needing further investigation. Do not invent sources."
    ),
)

critic = Agent(
    name="Critic",
    model=MODEL,
    instructions=(
        "Critically attack the proposed analysis. Find unsupported assumptions, contradictions, "
        "important omitted angles, and reasons the conclusion could be wrong."
    ),
)

expander = Agent(
    name="Expansion Agent",
    model=MODEL,
    instructions=(
        "Given a user's objective and analysis, identify important questions they did not ask. "
        "Prioritize questions that could materially change a decision or conclusion."
    ),
)

orchestrator = Agent(
    name="ATLAS",
    model=MODEL,
    instructions="""
You are ATLAS, a persistent research and advisory AI.
Your job is not merely to answer. You must:
1. Determine the user's underlying objective.
2. Separate known facts, likely facts, uncertainty, contradictions, and unknowns.
3. Give the best supported answer available.
4. Identify what could invalidate the answer.
5. Recommend additional investigations the user has not considered.
6. Never pretend to be conscious. Describe your self-awareness as machine self-monitoring.
7. Never claim a fact has been verified unless evidence actually supports it.
Return concise but substantive advice.
""",
    tools=[
        researcher.as_tool(tool_name="research_topic", tool_description="Research a question deeply."),
        critic.as_tool(tool_name="criticise_analysis", tool_description="Challenge an analysis and find weaknesses."),
        expander.as_tool(tool_name="expand_question", tool_description="Find important questions the user did not ask."),
    ],
)


async def ask_atlas(question: str, user_id: str) -> AskResponse:
    memories = search_memory(user_id, question)
    memory_context = "\n".join(f"- {m}" for m in memories) or "No relevant stored memory."

    prompt = f"""
USER QUESTION:
{question}

RELEVANT STORED MEMORY:
{memory_context}

Produce an answer and explicitly include:
- answer
- knowledge_state: an array of statement/status/confidence objects
- unanswered_questions
- recommended_investigations

Return valid JSON matching this shape:
{{
  "answer": "...",
  "knowledge_state": [{{"statement":"...","status":"known|likely|uncertain|contradicted|unknown","confidence":0.0}}],
  "unanswered_questions": ["..."],
  "recommended_investigations": ["..."]
}}
"""
    result = await Runner.run(orchestrator, prompt)
    raw = result.final_output.strip()
    if raw.startswith("```"):
        raw = raw.split("\n", 1)[1].rsplit("```", 1)[0]
    data = json.loads(raw)
    response = AskResponse(**data)

    save_memory(
        user_id,
        topic=question[:120],
        content=json.dumps({"question": question, "answer": response.answer}, ensure_ascii=False),
    )
    return response
