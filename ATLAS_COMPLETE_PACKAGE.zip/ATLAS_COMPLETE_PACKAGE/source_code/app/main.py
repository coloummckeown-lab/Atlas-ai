from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.schemas import AskRequest, AskResponse
from app.agents.core import ask_atlas
from app.memory.store import init_db
from app.evolution.engine import evolution_contract, source_manifest

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"

app = FastAPI(title="ATLAS V1", version="0.2.0")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.on_event("startup")
def startup() -> None:
    init_db()


@app.get("/", include_in_schema=False)
def home():
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/manifest.webmanifest", include_in_schema=False)
def manifest():
    return FileResponse(STATIC_DIR / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/service-worker.js", include_in_schema=False)
def service_worker():
    return FileResponse(STATIC_DIR / "service-worker.js", media_type="application/javascript")


@app.get("/health")
def health():
    return {"status": "ok", "system": "ATLAS", "version": "0.2.0"}


@app.post("/ask", response_model=AskResponse)
async def ask(req: AskRequest):
    try:
        return await ask_atlas(req.question, req.user_id)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/evolution/policy")
def get_evolution_policy():
    return evolution_contract()


@app.get("/evolution/source-manifest")
def get_source_manifest():
    return {"files": source_manifest()}
