from pydantic import BaseModel, Field
from typing import Literal


class AskRequest(BaseModel):
    question: str = Field(min_length=1)
    user_id: str = "local-user"


class KnowledgeItem(BaseModel):
    statement: str
    status: Literal["known", "likely", "uncertain", "contradicted", "unknown"]
    confidence: float = Field(ge=0, le=1)


class AskResponse(BaseModel):
    answer: str
    knowledge_state: list[KnowledgeItem] = []
    unanswered_questions: list[str] = []
    recommended_investigations: list[str] = []


class ImprovementProposal(BaseModel):
    title: str
    reason: str
    target_files: list[str]
    proposed_change: str
    test_plan: list[str]
    risk_level: Literal["low", "medium", "high"]
    requires_human_approval: bool = True
