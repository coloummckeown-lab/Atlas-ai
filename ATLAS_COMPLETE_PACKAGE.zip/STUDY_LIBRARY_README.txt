CMK 3.4 Study Library
- Dedicated GCSE Mathematics menu (Foundation/Higher topic library)
- Dedicated A Level Mathematics menu (Pure, Statistics, Mechanics)
- Official past-paper source library for AQA, Pearson Edexcel and OCR
- Annual/on-open web refresh check for the newest publicly available papers
- Dedicated University of Exeter Business & Finance menus: Year 1, Year 2, Final year, Study notes
- Course map based on University of Exeter BSc Finance: Business Management public module structure
- Core module study notes with formulas, tables and diagrams; optional module catalogue with Merlin-generated packs
- Exeter refresh function checks current official University sources
Note: official exam-board papers are linked rather than republished, respecting copyright and restricted teacher-only material.
